USE [MANAGEMENT]
GO

/****** Object:  StoredProcedure [dbo].[DV_CHECK_ORPHANUSER_New]    Script Date: 11/27/2018 7:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[DV_CHECK_ORPHANUSER_New]    
AS    

--SET NOCOUNT ON;
--DECLARE @SQL NVARCHAR(MAX), @DBName varchar(100)
--DECLARE @Results TABLE (DBName SYSNAME, UserName SYSNAME, UserSID VARBINARY(MAX), Remarks varchar(100))  
DECLARE @tableHTML  NVARCHAR(MAX);

--DECLARE cur CURSOR STATIC  FOR 
--SELECT name FROM sys.databases 
--WHERE	database_id > 4 
--		AND DATABASEPROPERTYEX(name, 'Status') <> 'OFFLINE' 
--		AND DATABASEPROPERTYEX(name, 'Status') <> 'LOADING' 

--OPEN cur  
--FETCH NEXT FROM cur into @DBName  

--WHILE @@FETCH_STATUS = 0 
--BEGIN 
--	SET @SQL = 'USE ' + @DBName + ';SELECT ''' + @DBName + ''' AS DBName, 
--			UserName = a.name, UserSID = a.sid, null from sysusers a LEFT OUTER JOIN sys.server_principals b ON a.name COLLATE DATABASE_DEFAULT = b.name COLLATE DATABASE_DEFAULT
--			WHERE	(a.sid <> b.sid )
--			--WHERE	a.sid <> b.sid
--            and		a.issqluser = 1 
--            and		(a.sid is not null and a.sid <> 0x0)
--            and		(len(a.sid) <= 16)
--            --and		a.name like ''%CPUSER%''
--            and		suser_sname(a.sid) is null
--            order by a.name'     

--INSERT INTO @Results 
--	EXEC(@SQL)  

--Update @Results 
--Set Remarks = 'Orphan Users (SID mismatch)'
--where Remarks is null

----SET @SQL = 'USE ' + @DBName + ';SELECT ''' + @DBName + ''' AS DBName, 
----			UserName = a.name, UserSID = a.sid, null from sysusers a LEFT OUTER JOIN sys.server_principals b ON a.name COLLATE DATABASE_DEFAULT = b.name COLLATE DATABASE_DEFAULT
----			WHERE	(b.name is null)
----			--WHERE	a.sid <> b.sid
----            and		a.issqluser = 1 
----            and		(a.sid is not null and a.sid <> 0x0)
----            and		(len(a.sid) <= 16)
----            --and		a.name like ''%CPUSER%''
----            and		suser_sname(a.sid) is null
----            order by a.name'     

----INSERT INTO @Results 
----	EXEC(@SQL)

----Update @Results 
----Set Remarks = 'Missing Logins'
----where Remarks is null

--	FETCH NEXT FROM cur into @DBName  
--END  

--CLOSE cur 
--DEALLOCATE cur  
/* New Logic Add */
	
DECLARE @DB_Users TABLE (DBName [varchar](30), 
UserName [varchar](100), 
LoginType [varchar](20),
AssociatedRole [varchar](100), Login_create_date datetime, Login_modify_date datetime, db_login_create_date datetime
, db_login_modify_date datetime
, 	[ObjectType] [varchar](60) ,
	[SchemaName] [varchar](30) ,
	[ObjectName] [varchar](100) ,
	[PermissionType] [varchar](20) ,
	[PermissionState] [varchar](20))

	
INSERT @DB_Users
EXEC sp_MSforeachdb
'use [?]
SELECT ''?'' AS DB_Name,
case prin.name when ''dbo'' then prin.name + '' (''
    + (select SUSER_SNAME(owner_sid) from master.sys.databases where name =''?'') + '')''
    else prin.name end AS UserName,
    prin.type_desc AS LoginType,
    isnull(USER_NAME(mem.role_principal_id),'''') AS AssociatedRole, 
    SerPrin.create_date Server_CreateDate, SerPrin.modify_date Server_ModifyDate,
	Prin.create_date Database_LoginCreateDate, Prin.modify_date Database_LoginModifyDate
	,null, null, null, null, null
FROM sys.database_principals prin
Join sys.server_principals SerPrin
	On prin.name COLLATE DATABASE_DEFAULT =SerPrin.name COLLATE DATABASE_DEFAULT
LEFT OUTER JOIN sys.database_role_members mem
    ON prin.principal_id=mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00)
and prin.is_fixed_role <> 1 AND prin.name NOT LIKE ''##%''  and prin.type_desc in (''SQL_USER'', ''WINDOWS_USER'', ''WINDOWS_GROUP'')'

INSERT @DB_Users
EXEC sp_MSforeachdb
'USE [?];
		SELECT ''?'' AS DBName,
		sp.name as UserName
		,case when isnull(sp.name,'''') = '''' and isnull(dp.name,'''') <> '''' then ''SQL user without Login'' else sp.type_desc end as LoginType
		, null, null, null, null, null
		,case when isnull(cl.name,'''') <> '''' then ''TABLE_COLUMN'' else isnull(obj.type_desc,'''') end as ObjectType
		,isnull(USER_NAME(obj.schema_id),'''') as SchemaName
		,case when isnull(cl.name,'''') <> '''' then isnull(obj.name,'''') + ''.'' + isnull(cl.name,'''') else isnull(obj.name,'''') end as ObjectName 


		,dperm.permission_name as PermissionType , dperm.state_desc as PermissionState
		FROM  sys.database_permissions AS dperm
				INNER JOIN sys.objects AS obj ON dperm.major_id = obj.[object_id]
				INNER JOIN sys.database_principals AS dp ON dperm.grantee_principal_id = dp.principal_id
				LEFT JOIN sys.columns AS cl ON cl.column_id = dperm.minor_id AND cl.[object_id] = dperm.major_id
				left outer join sys.server_principals sp on sp.sid = dp.sid
		WHERE dp.principal_id not in (2,3) and sp.name not like ''##MS%'' and dp.name IN ( Select name from sys.database_principals Where principal_id not in(2,3) And type in (''S'',''U'',''G'')) '

--print '1'

select dbUsers.*
into #UsersInfo
from @DB_Users dbUsers
	join sys.server_principals Users
		on dbUsers.UserName = Users.name
where is_disabled = 0
--print '2'

CREATE CLUSTERED INDEX IDX_DV_UsersInformation ON #UsersInfo
(
      DBName ASC,
	  UserName ASC,
LoginType ASC,
AssociatedRole ASC,
ObjectType ASC,
SchemaName ASC,
ObjectName ASC,
PermissionType ASC,
PermissionState ASC
)
WITH (STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING =OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

--print '3'
/*New Logic End*/
--SELECT * FROM @Results
IF EXISTS (select *
from DV_UsersInformation DV_UI
	left join #UsersInfo UI
		on DV_UI.dbname = UI.dbname and
			DV_UI.UserName = UI.UserName and
			DV_UI.LoginType = UI.LoginType and
			isnull(DV_UI.AssociatedRole, '') = isnull(UI.AssociatedRole, '') and 
			isnull(DV_UI.ObjectType, '') = isnull(UI.ObjectType, '') and
			isnull(DV_UI.SchemaName, '') = isnull(UI.SchemaName, '') and
			isnull(DV_UI.ObjectName, '') = isnull(UI.ObjectName, '')  and
			isnull(DV_UI.PermissionType, '') = isnull(UI.PermissionType, '') and
			isnull(DV_UI.PermissionState, '') = isnull(UI.PermissionState, '')
where UI.DBName is null)

BEGIN  
--print '4'

SET @tableHTML =
    N'<H1>Orphan User / Permission missing Report on SNDB12/SNSERVER12 </H1>' +
    N'<table border="1">' +
    N'<tr><th>DBName</th><th>UserName</th>' +
    N'<th>LoginType</th>' +
        N'<th>AssociatedRole</th>' +
            N'<th>ObjectType</th>' +
                --N'<th>SchemaName</th>' +
                    N'<th>ObjectName</th>' +
                        N'<th>PermissionType</th>' +
    N'<th>PermissionState</th><th>' +
    
    CAST ((select td = DV_UI.DBName, '',
		td = DV_UI.UserName, '',
		td = DV_UI.LoginType, '' ,
		td = isnull(DV_UI.AssociatedRole, '') , '',
		td = isnull(DV_UI.ObjectType, ''), '',
		--td = isnull(DV_UI.SchemaName, ''), '',
		td = isnull(DV_UI.ObjectName, ''), '',
		td = isnull(DV_UI.PermissionType, ''), '',
		td = isnull(DV_UI.PermissionState, '')
		
			
from DV_UsersInformation DV_UI
	left join #UsersInfo UI
		on DV_UI.dbname = UI.dbname and
			DV_UI.UserName = UI.UserName and
			DV_UI.LoginType = UI.LoginType and
			isnull(DV_UI.AssociatedRole, '') = isnull(UI.AssociatedRole, '') and 
			isnull(DV_UI.ObjectType, '') = isnull(UI.ObjectType, '') and
			isnull(DV_UI.SchemaName, '') = isnull(UI.SchemaName, '') and
			isnull(DV_UI.ObjectName, '') = isnull(UI.ObjectName, '')  and
			isnull(DV_UI.PermissionType, '') = isnull(UI.PermissionType, '') and
			isnull(DV_UI.PermissionState, '') = isnull(UI.PermissionState, '')
where UI.DBName is null
    FOR XML PATH('tr'), TYPE 
    ) AS NVARCHAR(MAX) )
+ N'</table>' +
 N'<H3> Note: Please provide the mention permission on specific login for specific object. Do not fix the orphan users. </H3>'   
    --CAST ( ( SELECT td = DBName,       '',
    --                td = UserName, '',
    --                td = UserSID, '',
    --                td = Remarks, '',
    --                td = 'EXEC sp_change_users_login ' + '''update_one''' + ',' + ''''+ UserName + '''' + ',' + ''''+ UserName + ''''
    --          from @Results
    --          FOR XML PATH('tr'), TYPE 
    --) AS NVARCHAR(MAX) )
--print @tableHTML
EXEC msdb.dbo.sp_send_dbmail @profile_name = 'HMDX_DBMail',     
	@recipients = 'it@healthmedx.com;sql@datavail.com;Manish.Trivedi@datavail.com; Harnish.Desai@datavail.com', 
	--@recipients = 'Harnish.Desai@datavail.com', 
    @subject = 'Orphan User / Permission missing Report on SNDB12/SNSERVER12',
    @body = @tableHTML,
    @body_format = 'HTML' 

END







GO

