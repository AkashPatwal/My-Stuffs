<################################################################################
BACKUP REPORT (PS script to loop trough the server list and execute the Report.sql file on each server)

DESCRIPTION: The script will connect to the instance(s) and generate a report for database backups. The script can run centrally from one server and access multiple instances to generate a consolidated report.
             The report will also color code the backups last finish dates based in the thresholds provided for each server and backup type.
             The report requires an input file "Server-List.txt" that lists the instance name, thresholds, smtp address and email list.


AUTHOR: Anup Gopinathan
DATE:   04 Aug 2012

Server-List.txt
             The file has to be created in the same folder where this .ps1 file is placed.
             Below is the input format required.

                @FROM=<alert@alerting.com>
                @SMTP=<mail-relay.mailing.local>
                @RECT=<id1,id2,....,idN>
                @CLIENT=<client name or specific text, this will be appended to email subject>
                -- Can use "--" at start of a line to comment
                ------------------------------------------------------------------------------------
                --InstanceName<;PORT optional>,FULLBACKUP_threshold_in_minutes,DIFFBACKUP_threshold_in_minutes,TLogBACKUP_threshold_in_minutes(database exclude list<db1,db2,.....dbN>)
                ------------------------------------------------------------------------------------
                SQLINSTANCE,10080,1440,60
                --SQLINSTANCE will be connected and backup would be highlighted in red if fullbackups date is older than 10080 minutes from the datetime the report is run, 
                --like wise differential backup will in red if previous backup is older than 1440 since script execution date
                Server:1433,10080,1440,60
                --Port number can be used as displayed above
                SQLINSTANCE,10080,1440,60(master,model)
                --Report will exclude details for "master and model" databases
             
             
	
PARAMETER(S): $REPORTorALERT          - Mandatory parameter,
                                        Values = REPORT/ALERT, If REPORT, backup details report will be generated, report will have details of all the databases on the instance. Ideal for daily reviewing backups across all servers
                                                               If ALERT, a report for databases for which the backups did not happen within the threshold time specified are listed. Ideal for alert and ticket generation.
              $ATTACHREPORT           - Mandatory parameter,
                                       $true/$false, If $true then Report is sent as an attachment,
                                                     If $false then Report is embedded in email as html.


COMMAND: ./backupreport.ps1 -REPORTorALERT REPORT -ATTACHREPORT $false -- Generates backup details report and emails report embedded in email
COMMAND: ./backupreport.ps1 -REPORTorALERT REPORT -ATTACHREPORT $true -- Generates backup details report and attaches report in email
COMMAND: ./backupreport.ps1 -REPORTorALERT ALERT -ATTACHREPORT $false -- Generates backup alert report and emails report embedded in email
COMMAND: ./backupreport.ps1 -REPORTorALERT ALERT -ATTACHREPORT $true -- Generates backup alert report and emails report embedded in email
	
OUTPUT: none
	  
PERMISSION REQUIRED FOR EXECUTING
    For successful execution, the following configurations and privileges are needed:
    - Sysadmin privileges to MSSQL instances
    - Should have access to all sql instances from the central server, only if run from a central server.

UPDATES:
    UPDATED: 03/28/2018
        - Added parameter $REPORTorALERT

	
    UPDATED: 06/05/2018  
         - Added parameter $ATTACHREPORT,

################################################################################>


###################################################
# Start - Parameter Definition
###################################################

param(
        [Parameter(Mandatory=$true)] [String] $REPORTorALERT,
        [Parameter(Mandatory=$true)] [bool] $ATTACHREPORT
    )


clear; # clear the screen
$i=0
$Date = ( get-date ).ToString('yyyy/MM/dd') 
###################################################
# Start - Loading Module/Snapins
###################################################
if (-not(Get-Module -Name SQLPS) -and (-not(Get-PSSnapin -Name SqlServerCmdletSnapin100, SqlServerProviderSnapin100 -ErrorAction SilentlyContinue))) {
    Write-Verbose -Message 'SQLPS PowerShell module or snapin not currently loaded'
 
        if (Get-Module -Name SQLPS -ListAvailable) {
        Write-Verbose -Message 'SQLPS PowerShell module found'
 
            Push-Location
            Write-Verbose -Message "Storing the current location: '$((Get-Location).Path)'"
 
            if ((Get-ExecutionPolicy) -ne 'Restricted') {
                Import-Module -Name SQLPS -DisableNameChecking -Verbose:$false
                Write-Verbose -Message 'SQLPS PowerShell module successfully imported'
            }
            else{
                Write-Warning -Message 'The SQLPS PowerShell module cannot be loaded with an execution policy of restricted'
            }
            
            Pop-Location
            Write-Verbose -Message "Changing current location to previously stored location: '$((Get-Location).Path)'"
        }
        elseif (Get-PSSnapin -Name SqlServerCmdletSnapin100, SqlServerProviderSnapin100 -Registered -ErrorAction SilentlyContinue) {
        Write-Verbose -Message 'SQL PowerShell snapin found'
 
            Add-PSSnapin -Name SqlServerCmdletSnapin100, SqlServerProviderSnapin100
            Write-Verbose -Message 'SQL PowerShell snapin successfully added'
 
            [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Smo') | Out-Null
            Write-Verbose -Message 'SQL Server Management Objects .NET assembly successfully loaded'
        }
        else {
            Write-Warning -Message 'SQLPS PowerShell module or snapin not found'
        }
    }
    else {
        Write-Verbose -Message 'SQL PowerShell module or snapin already loaded'
    }
###################################################
# End - Loading Module/Snapins
###################################################


###################################################
# Start - Function Send Email
###################################################
Function sendEmail 
{
    param($from,$to,$subject,$smtphost,$htmlFileName,$ATTACHREPORT)

    if (!($ATTACHREPORT))
    {
        $body = Get-Content $htmlFileName
    }
    else
    {
        $body = Get-Content $htmlFileName
    }
    $smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
    $msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
    $msg.isBodyhtml = $true
    if ($ATTACHREPORT)
    {
        $attachment = New-Object System.Net.Mail.Attachment($htmlFileName, 'text/plain')
        $msg.Attachments.Add($attachment)
    }
    $smtp.send($msg) 
}
###################################################
# End - Function Send Email
################################################### 

$path = split-path -parent $MyInvocation.MyCommand.Definition  -ErrorAction stop
$hostname = get-content env:computername -ErrorAction stop
$globalPath = "\\$hostname\$path" -replace ":", "$"
[String]$clientName=""

Write-host "##---------------------------------------------------##" -fore BLACK -background WHITE
Write-host " " -fore BLACK -background WHITE
Write-host "Root Path:"$path  -fore BLACK -background WHITE
Write-host "Hostname:"$hostname  -fore BLACK -background WHITE
Write-host "Global Path:"$globalPath  -fore BLACK -background WHITE
Write-host " "  -fore BLACK -background WHITE


# write code for getting a server list
$getServerList = get-Content "$globalPath\Server-List.txt"
if ($getServerList -eq $null)
    {$getServerList = $hostname}

if((test-path "$globalPath\BackupReport.HTML" -pathtype Leaf))
	{Remove-Item "$globalPath\BackupReport.HTML"}
    
$myData = @()
$svrProp = @()
$smtpAdd = @()
$recp = @()  
$frm = @()
$params = @()
    
foreach ($item in $getServerList)
    {
        if (!$item)
        {$item = "--"}
    
        if (($item.Substring(0,2) -ne "--"))
	    {
    	    if ($item.Substring(0,1) -eq "@")
            {
			    $params = $item.split("=")
                if ($params[0] -eq "@SMTP")
                {
        		    $mailex = $params[1]
        	}
        	if ($params[0] -eq "@RECT")
    		    {
    			    $recpt = $params[1]
    		    }
		if ($params[0] -eq "@FROM")
    		    {
    			    $frm = $params[1]
    		    }
		if ($params[0] -eq "@CLIENT")
    		    {
    			    $client = $params[1]
    		    }
            }
            else
            {
                if ($item.Contains("("))
                {
                    $svrProp = $item.split("(")
                    Write-host $svrProp[0]
                    Write-host $svrProp[1]
                
                    $svrDet = $svrProp[0]
                    $excList = $svrProp[1].split(")")
                    $excDBlist = $excList[0]
                    $excDBlist = "'$excDBlist'"
                
                    Write-host "-----------"
                    Write-host $svrDet
                    Write-host $excDBlist               
                
                    $svrConn = $svrDet.split(",")
                    $getServer = $svrConn[0]
                    $full = $svrConn[1]
                    $diff = $svrConn[2]
                    $tlog = $svrConn[3]
                }
                else
                {
                    $svrConn = $item.split(",")
                    $getServer = $svrConn[0]
                    $full = $svrConn[1]
                    $diff = $svrConn[2]
                    $tlog = $svrConn[3]
                    $excDBlist = "''"
                }               

                #EXIT
                if (!$getServer)
                {
                    Write-host "Cannot proceed without Server name"
                    EXIT
                }
                if (!$full)
                {
                    $full = 0
                }
                if (!$diff)
                {
                    $diff = 0
                }
                if (!$tlog)
                {
                    $tlog = 0
                }
                if (!$excDBlist)
                {
                    $excDBlist = ""
                }
                if ((!$REPORTorALERT))
                {
                    Write-output "Value for paramater REPORTorALERT mentioned is incorrect, default value will be taken i.e. REPORT"
                    $REPORTorALERT = "REPORT"
                }
                if($REPORTorALERT -eq "ALERT")
                {
                    $AlertOnly = "1"
                    $emailSubject = "$Client :: Backup Missing Alert - $Date"
                }
                else
                {
                    $AlertOnly = "0"
                    $emailSubject = "$Client :: Backup Report - $Date"
                }



                $vsql = "full=$full", "diff=$diff", "tlog=$tlog", "AlertOnly=$AlertOnly", "excDBlist=$excDBlist"
                
                $getServer = $getServer.replace(";", ",")
                Write-host "Server: $getServer Thresholds for, Full: $full Diff: $diff Tlogs: $tlog AlertOnly: $AlertOnly excDBlist: $excDBlist" -fore BLACK -background WHITE
            
        	    $myData = invoke-sqlcmd -InputFile "$globalPath\Report.sql" -serverinstance $getServer -database tempdb -querytimeout ([int]::MaxValue) -MaxCharLength 1000000 -Variable $vsql;
        	    #$mydata | out-file "$globalPath\BackupReport.HTML" -Append -Width 1000000;
                $col = ""
                $col = $mydata.Col
                $col = $col.Substring(6, ($col.length-6))
                $col | out-file "$globalPath\BackupReport.HTML" -Append -Width 1000000;
        	    $i += 1;
            }
        }
    }
    $Gtdate = Get-Date
    $yy = $Gtdate.Year
    $Fnote = "<p align=""center"" class=""footnote"">
    <font face=""Segoe UI"" size=""1"">
    This report was executed on $hostname<br>&copy; 2008&mdash;$yy datAvail Corporation.<br/>
    This is intellectual property of datAvail Corporation;.<br/>
    Any use or modification without prior notification and permission is illegal and will be prosecuted.
    </font>
    </p>"
    $Fnote | out-file "$globalPath\BackupReport.HTML" -Append -Width 1000000;

    Write-host "Backup report executed for $i server(s)." -fore BLACK -background WHITE

    #Remove-PSSnapin SqlServerCmdletSnapin100;

    if (!$frm -or !$mailex -or !$recpt)
    {
        Write-host "Reports cannot be emailed as either SMTP address or receipent address is not given..." -fore BLACK -background WHITE
        exit
    }
    sendEmail $frm $recpt $emailSubject $mailex "$globalPath\BackupReport.HTML" $ATTACHREPORT
    Write-host "Backup report emailed to $recpt"
    EXIT
#}
#Catch
#{
    #$ErrorMessage = $_.Exception.Message
    #$ErrorMessage | out-file -Append -filepath "$globalPath\failed.log"
#}