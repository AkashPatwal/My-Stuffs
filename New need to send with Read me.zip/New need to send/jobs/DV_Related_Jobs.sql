USE [msdb]
GO

/****** Object:  Job [DV Audit_login]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Audit_login', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Audit_login]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Audit_login', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

Set  nocount on
declare @sOSQL_cmd varchar(8000)
declare @batch_id int
declare @sBody varchar(8000),@local_host varchar(100),@Ssub varchar(150)
select @local_host=host_name()
select @Ssub = ''Login with 32 user name found in '' + ltrim(rtrim(@@servername)) 
   
SET @sBody = ''Healthmedx Team Login with 32 in user name is found in '' + LTRIM(rtrim(@@servername)) +  char(13) + char(13) + ''Please look into it.'' + ''Login Audit  on '' + ltrim(rtrim(@@servername)) + '' produced this alert.''  + char(13) + char(13) + ''Thanks''   

Create table #temp (client_net_address varchar(50),[host_name] varchar(50),login_name varchar(50),connect_time datetime)
Create table #temp1 (client_net_address varchar(50),[host_name] varchar(50),login_name varchar(50),connect_time datetime)

IF exists(select top 1 * from management.dbo.tbl_audit_login_32)
select @batch_id = max(batch_id)+1 from management.dbo.tbl_audit_login_32
else
set @batch_id = 1

declare @sql nvarchar(1000)
declare @sql1 nvarchar(1000)

set @sql= ''select '' +  '' sys.'' + ''dm_exec_connections.'' + ''client_net_address'' + '' , '' +  ''sys.dm_exec_sessions.host_name'' + '', '' +''sys. dm_exec_sessions.login_name ''+ '','' + ''sys.dm_exec_connections.connect_time'' + '' from '' + ''sys.dm_exec_connections''+'' inner join '' + ''sys.dm_exec_sessions '' + '' on '' + ''sys.dm_exec_connections.session_id = sys.dm_exec_sessions.session_id where dm_exec_sessions.host_name '' + ''not in '' +''(''+''''''HMDXASPAPP00''''''+'',''+ ''''''HMDXASPAPP01''''''+'',''+ ''''''HMDXASPAPP02''''''+'',''++ ''''''HMDXASPAPP03''''''+'',''++ ''''''HMDXASPAPP04''''''+'',''++ ''''''HMDXASPAPP05''''''+'',''++ ''''''HMDXASPAPP06''''''+'',''++ ''''''HMDXASPAPP07''''''+'',''++ ''''''HMDXASPAPP08''''''+'',''++ ''''''HMDXASPAPP09''''''+'',''++ ''''''HMDXASPAPP10''''''+'',''++ ''''''HMDXASPAPP11''''''+'',''++ ''''''HMDXASPAPP12''''''+'',''++ ''''''HMDXASPAPP13''''''+'',''++ ''''''HMDXASPAPP14''''''+'',''++ ''''''HMDXASPMG19''''''+'',''++ ''''''HMDXASPMG20''''''+'',''++ ''''''hmdxaspapp21''''''+'',''++ ''''''hmdxaspapp22''''''+'',''''''+@local_host+'''''')''+ '' and ''+ ''sys.dm_exec_sessions.login_name ''+ ''like ''+ ''''''%32%''''''
insert into #temp exec(@sql)

Insert into #temp1
select distinct a.* from #temp A left outer join management.dbo.tbl_audit_login_32 B on a.login_name = b.login_name and a.connect_time = b.connect_time
where b.login_name is null and b.connect_time is null

Insert into management.dbo.tbl_audit_login_32
select distinct @batch_id,a.*,getdate() from #temp A left outer join management.dbo.tbl_audit_login_32 B on a.login_name = b.login_name and a.connect_time = b.connect_time
where b.login_name is null and b.connect_time is null

select * from #temp1
select * from management.dbo.tbl_audit_login_32 where batch_id = @batch_id
print @batch_id

set @sql1 = ''select client_net_address,host_name,login_name,connect_time from management.dbo.tbl_audit_login_32 where batch_id = (select max(batch_id) from management.dbo.tbl_audit_login_32)''

---Commented by Amit:-IF EXISTS (SELECT top 1 * FROM #temp1) 
IF EXISTS (SELECT top 1 * FROM #temp1 where login_name not in (select distinct login_name from management.dbo.tbl_audit_login_32) )
begin 

	set @sOSQL_cmd = ''OSQL -S '' + @@servername +'' -E -n -h -v -w10000 -Q "''+@sql1+''" > C:\DV\Audit_login.txt''
	EXEC master..xp_cmdshell @sOSQL_cmd
	    
	begin
		EXEC msdb..sp_CDOMail    
		@To    = ''kelly.woods@healthmedx.com'',
		--@To    = ''amit.kumar@datavail.com'',
		@From    = ''datapalette@datavail.com'',    
		@Subject   = @sSub,    
		@Body    = @sBody,	
		@FilePath = ''C:\DV\'',
		@FileName = ''Audit_login.txt''
	end
end

drop table #temp
drop table #temp1', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DV_audit_Login', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110614, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'42a59467-6ea1-40c3-bdeb-9bec1e4fa974'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV bounceDelta]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV bounceDelta', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step 1]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'net stop deltaagent

', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [clear cashe]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'clear cashe', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'WAITFOR DELAY ''00:01'';
go

exec xp_cmdshell ''del "C:\Program Files\Datavail\Delta Agent\cache\*" /Q /F''

WAITFOR DELAY ''00:01'';
go', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step 2]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step 2', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'net start deltaagent', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'bounceDelta', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120320, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'cb80bfa5-8527-4e3f-a08f-a1f13c25f895'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV Check_VLF_Count]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Check_VLF_Count', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Check_VLF_Count]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Check_VLF_Count', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON;
declare @query varchar(100) 
declare @dbname sysname 
declare @vlfs int 
DECLARE @tableHTML  NVARCHAR(MAX);
 

declare @databases table (dbname sysname) 
insert into @databases 
--only choose online databases 
select name from sys.databases where state = 0 
 
--table variable to hold results 
declare @vlfcounts table 
    (dbname sysname, 
    vlfcount int) 
 
--table varioable to capture DBCC loginfo output 
declare @dbccloginfo table 
( 
    recoveryunitid tinyint, 
    fileid tinyint, 
    file_size bigint, 
    start_offset bigint, 
    fseqno int, 
    [status] tinyint, 
    parity tinyint, 
    create_lsn numeric(25,0) 
) 
 
while exists(select top 1 dbname from @databases) 
begin 
 
    set @dbname = (select top 1 dbname from @databases) 
    set @query = ''dbcc loginfo ('' + '''''''' + @dbname + '''''') WITH NO_INFOMSGS '' 
 
    insert into @dbccloginfo 
    exec (@query) 
 
    set @vlfs = @@rowcount 
 
    insert @vlfcounts 
    values(@dbname, @vlfs) 
 
    delete from @databases where dbname = @dbname 
 
end 
 


IF EXISTS ( SELECT top 1 * FROM @vlfcounts where vlfcount>1000)  
BEGIN  

SET @tableHTML =
    N''<H1>High VLF Count DBs </H1>'' +
    N''<table border="1">'' +
    N''<tr><th>dbname</th><th>vlfcount</th>'' +
    CAST ( ( SELECT td = DBName,       '''',
                    td = VLFCount, ''''
              from @vlfcounts 
              where vlfcount>1000
				order by dbname
              FOR XML PATH(''tr''), TYPE 
    ) AS NVARCHAR(MAX) ) +
    N''</table>'' ;


declare @sub varchar(100)
set @sub = ''High VLF Count DBs on ''+@@servername

EXEC msdb.dbo.sp_send_dbmail @profile_name = ''HMDX_DBmail'',     
    @recipients = ''kelly.woods@healthmedx.com;sql@datavail.com'',
    @subject = @sub,
    @body = @tableHTML,
    @body_format = ''HTML'' 

END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DV_Check_VLF_Count_Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130906, 
		@active_end_date=99991231, 
		@active_start_time=200000, 
		@active_end_time=235959, 
		@schedule_uid=N'aff089d0-3148-4de0-be2c-bdc6a8923e36'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV DR_Sync]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV DR_Sync', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [script out jobs]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'script out jobs', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'&C:\DV\DR_Scripts\script_out_jobs.ps1 ''SNDB05\SNSERVER05''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [write job script to share]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'write job script to share', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

exec dbo.getJobScript', 
		@database_name=N'master', 
		@output_file_name=N'\\hmdxcidsnvss01\DataVail\DR\snSQL01\snSQL01_DR_JobScript.sql', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [purge job script table]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'purge job script table', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

delete DR_JobScripts where AsOfDate > datediff(d,-5,getdate())', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [script out db owners]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'script out db owners', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

exec recordDatabaseOwnerScript;
go', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [write dbowners script to share]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'write dbowners script to share', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

exec dbo.getDatabaseOwnerScript', 
		@database_name=N'MANAGEMENT', 
		@output_file_name=N'\\hmdxcidsnvss01\DataVail\DR\snSQL01\snSQL01_DR_DatabaseOwnerScript.sql', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [purge db owners script table]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'purge db owners script table', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

delete DR_DatabaseOwnerScripts  where AsOfDate > datediff(d,-5,getdate())', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [script out logins]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'script out logins', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe C:\DV\DR_Scripts\script_out_logins.ps1 ''SNDB05\SNSERVER05''', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [write login script to share]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'write login script to share', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

exec dbo.getLoginScript', 
		@database_name=N'MANAGEMENT', 
		@output_file_name=N'\\hmdxcidsnvss01\DataVail\DR\snSQL01\snSQL01_DR_LoginsScript.sql', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [purge logins script table]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'purge logins script table', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

delete DR_LoginScripts where AsOfDate > datediff(d,-5,getdate())', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DR_Sync', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130531, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=235959, 
		@schedule_uid=N'f53f5807-0d33-410a-879a-808d475aa787'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV Index Maintenance]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Index Maintenance', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Index Maintenance]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Index Maintenance', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use management;
go

Exec [DV_IndexMaintAndStats]
@OrgBuildThresh = 70,
@MaintFragThreshold = 30,
@MaintPageThreshold = 1000,
@verbose = ''Y''
', 
		@database_name=N'MANAGEMENT', 
		@output_file_name=N'F:\MSSQL10_50.SNSERVER01\MSSQL\Log\IndexMaintenanace.txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Defrag Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=63, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20070921, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'632d2e4c-4668-4b29-88c3-0a063275e0a4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV Job_Audit]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Job_Audit', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Job_Audit]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Job_Audit', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC usp_AuditJob', 
		@database_name=N'MANAGEMENT', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DV_JobAudit', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120625, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b610af2a-f0c1-412f-8c98-978cf9e7b45d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV Mirror Sync Report 30 minutes latency]    Script Date: 11/27/2018 6:22:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Mirror Sync Report 30 minutes latency', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Tran Sync Report 30 minutes latency]    Script Date: 11/27/2018 6:22:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Tran Sync Report 30 minutes latency', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec xp_cmdshell ''osql -S SNSQL01\SNSERVER01 -E master -Q "Exec master.dbo.usp_Mirror_Sync_Report"  -o F:\DV_Mirror_report\MirroringStatus.htm''', 
		@database_name=N'master', 
		@output_file_name=N'F:\DV_Mirror_report\output.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sendmail]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'sendmail', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'ActiveScripting', 
		@command=N'Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objFile = objFSO.GetFile("F:\DV_Mirror_report\MirroringStatus.htm")

Size = objFile.Size

If size > 100 Then

	Set objMessage = CreateObject("CDO.Message") 
	objMessage.Subject = "Mirroring Status" 
	objMessage.From = "datapalette@datavail.com" 
	objMessage.To = "sql@datavail.com;it@healthmedx.com" 
	objMessage.TextBody = "Please see the attached document which contains the SQL Server Mirroring Status ..." 
	objMessage.AddAttachment "F:\DV_Mirror_report\MirroringStatus.htm"

objMessage.Configuration.Fields.Item _
    ("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2

objMessage.Configuration.Fields.Item _
    ("http://schemas.microsoft.com/cdo/configuration/smtpserver") = "172.16.0.3"
objMessage.Configuration.Fields.Item _
    ("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25
objMessage.Configuration.Fields.Update


	objMessage.Send

End If


Set objFSO = Nothing
Set objFile = Nothing', 
		@database_name=N'VBScript', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV ple_per_numa_node]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV ple_per_numa_node', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step 1]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into ple_per_numa_node (asofdate,object_name, counter_name, instance_name, cntr_value, cntr_type)
Select getdate() asofdate, 
ltrim(rtrim(object_name)) object_name, ltrim(rtrim(counter_name)) counter_name,ltrim(rtrim(instance_name)) instance_name, cntr_value, cntr_type  
from sys.dm_os_performance_counters
where counter_name = ''Page life expectancy'' and object_name like ''%:%Buffer%Node%''', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'every 5 min', 
		@enabled=0, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160422, 
		@active_end_date=20160429, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'bac12fe6-356b-476f-9510-dd6365233cda'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV Replication Latency Alert]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV Replication Latency Alert', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Replication Alert]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Replication Alert', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [DV_Replication_latency_monitor] 1800', 
		@database_name=N'MANAGEMENT', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ReplicationAlert', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150202, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=205959, 
		@schedule_uid=N'90e1d3cc-5394-48cb-bf1d-a872fe5a3666'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV TempDB Autogrowth Alert]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Datavail]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Datavail' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Datavail'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV TempDB Autogrowth Alert', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Sends notifications to DBA when DATABASE File Growth event(s) occur(s)', 
		@category_name=N'Datavail', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send e-mail in response to WMI alert(s)]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send e-mail in response to WMI alert(s)', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

set @dbname = $(ESCAPE_SQUOTE(WMI(DatabaseName)))
if @dbname = ''tempdb''

Begin

set @sub =  ''Database file growth event - $(ESCAPE_SQUOTE(WMI(DatabaseName)))'' ;


EXEC msdb.dbo.sp_send_dbmail
    @profile_name = ''HMDX_DBMail'', -- update with your value
    @recipients = ''sql@datavail.com'', -- update with your value
    @body = ''File Name: $(ESCAPE_SQUOTE(WMI(FileName))); 
Start Time: $(ESCAPE_SQUOTE(WMI(STartTime))); 
Duration: $(ESCAPE_SQUOTE(WMI(Duration))); 
Application Name: $(ESCAPE_SQUOTE(WMI(ApplicationName))); 
Host Name: $(ESCAPE_SQUOTE(WMI(HostName))); 
Login Name: $(ESCAPE_SQUOTE(WMI(LoginName)));
Session Login Name: $(ESCAPE_SQUOTE(WMI(SessionLoginName)));'',
    @subject = @sub;

End', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_Backup_Purge_job]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_Backup_Purge_job', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge backup history]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge backup history', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use msdb
go

declare @date datetime
set @date = convert(datetime,CONVERT(VARCHAR(10),GETDATE()-30,10))
--print @date

Insert into Management.dbo.DV_Backup_history 
select A.Database_name, A.backup_start_date,A.backup_finish_date, A.type, b.physical_device_name
from msdb..backupset A , msdb..backupmediafamily B
where A.media_set_id=B.media_set_id and A.backup_start_date < @date
order by 2


Insert into management.dbo.DV_Restore_history
SELECT	rs.user_name,bs.[database_name] AS [source_database_name],rs.[destination_database_name],bs.[server_name] as [source_server_name]
,bmf.[physical_device_name] AS [backup_file_used_for_restore],rs.[restore_date],bs.[backup_start_date],bs.[backup_finish_date]
FROM	msdb.[dbo].[restorehistory] rs JOIN	msdb.[dbo].[backupset] bs ON rs.[backup_set_id] = bs.[backup_set_id]
JOIN	msdb.[dbo].[backupmediafamily] bmf ON bs.[media_set_id] = bmf.[media_set_id] 
where rs.restore_date <  @date
ORDER BY rs.[restore_date] 


EXEC sp_delete_backuphistory @oldest_date = @date
', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'purge schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150902, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=235959, 
		@schedule_uid=N'b5c84d15-c619-443f-b4c1-0c890fbdd3b6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_LongRunningTransaction]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_LongRunningTransaction', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Report]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Report', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @HTML VARCHAR(MAX),
@Subject VARCHAR(500),
@DBAMsg Varchar(500),
@ReportTitle Varchar(1000),
@threshold int,
@Rowsreturn int

SELECT @ReportTitle= convert(varchar(50),@@SERVERNAME)+'':: LONG RUNNNING TRANSACTION REPORT''
,@threshold=120 -- Please specify in minutes
,@ReportTitle=''<font size="4"><B>''+ltrim(rtrim(@ReportTitle))+''</B></font></BR>''
,@DBAMsg=''<html><body></BR> Hello Team </BR><BR>Please look into the below report for LONG RUNNING OPEN TRANSACTION</BR>''
 
--''<td valign="top">''+ CONVERT(VARCHAR(15), ISNULL(dt.database_transaction_begin_time, 0),101) + '' '' + CONVERT(VARCHAR(15), ISNULL(dt.database_transaction_begin_time, 0), 14) +
SET @HTML = ''<html><body>'' --<table border = 1>
+@ReportTitle
+ltrim(rtrim(@DBAMsg))+
''<table border = 1><tr style="background-color:Orange; height:20px;">
<th>Session ID</th>
<th>Database Name</th>
<th>Open_Tran</th>
<th>Transaction Type</th>
<th>Transaction Time</th>
<th>Individual Query</th>
<th>HostName</th>
<th>User</th>
<th>LoginName</th>
<th>Parent Query</th>
<th>Start Time</th>
<th>Status</th>
<th>ECID</th>
<th>Wait</th>
<th>Transaction Log record count</th>
<th>Transaction Log bytes used</th>
</tr>''

SET NOCOUNT ON--+--CASE WHEN dt.database_transaction_begin_time IS NULL THEN ''read-only'' ELSE ''read-write'' END +
SELECT @HTML = @HTML + ''<p><tr ><td valign="top"></p>''+ Cast(st.session_id as Varchar(10)) + 
''<td valign="top">''+ CASE WHEN dt.database_id = 32767 then ''resourceDb'' else DB_NAME(dt.database_id) end +
''<td valign="top">''+ convert(varchar(5),Qry.open_tran)+
''<td valign="top">''+ CASE  dt.database_transaction_type WHEN 1 then ''Read/write'' 
WHEN 2 then ''Read-only''
WHEN 3 then ''System''  
ELSE ''''
END+
''<td valign="top">''+ ltrim(rtrim(convert(varchar(20),dt.database_transaction_begin_time)))+
''<td valign="top">''+ SUBSTRING(Qry.[Individual Query], 1, 2000) +
''<td valign="top">''+ Qry.hostname +
''<td valign="top">''+ Qry.[User] +
''<td valign="top">''+ Qry.[loginame] +
''<td valign="top">''+ SUBSTRING(Qry.[Parent Query],1,2000) +
''<td valign="top">''+ CONVERT(VARCHAR(15), ISNULL(Qry.start_time, 0),101) + '' '' + CONVERT(VARCHAR(15), ISNULL(Qry.start_time, 0), 14) +
''<td valign="top">''+ Qry.Status + 
''<td valign="top">''+ CAST(ISNULL(ecid,0) as Varchar(10)) +
''<td valign="top">''+ CAST(ISNULL(Qry.Wait,0) as Varchar(10)) +
''<td valign="top">''+ CAST(dt.database_transaction_log_record_count as Varchar(20)) +
''<td valign="top">''+ CAST(dt.database_transaction_log_bytes_used as Varchar(20)) +
''</tr>''
FROM sys.dm_tran_session_transactions AS st 
INNER JOIN sys.dm_tran_database_transactions AS dt ON st.transaction_id = dt.transaction_id
JOIN (
SELECT [Spid] = session_Id
,ecid
,sp.open_tran as open_tran
,[Database] = DB_NAME(sp.dbid)
,[User] = nt_username
,sp.loginame
,[Status] = er.status
,[Wait] = wait_type
,[Individual Query] = SUBSTRING (qt.text, 
er.statement_start_offset/2,
(
CASE WHEN er.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX), qt.text)) * 2 
ELSE er.statement_end_offset END - 
er.statement_start_offset)/2)
,[Parent Query] = qt.text
, Program = program_name
, Hostname
, nt_domain
, start_time
--select * sys.sysprocesses
FROM  sys.dm_exec_requests er
LEFT JOIN sys.sysprocesses sp ON er.session_id = sp.spid
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle)as qt
WHERE session_Id > 50 -- Ignore system spids.
AND session_Id NOT IN (@@SPID) -- Ignore this current statement.
AND qt.text not like ''%WAITFOR(RECEIVE%''
---- Added above line to exclude this message ----
) Qry on st.session_id = Qry.Spid
WHERE DATEDIFF(mi, dt.database_transaction_begin_time,getdate() ) > @threshold AND dt.database_transaction_begin_time IS NOT NULL
And DB_NAME(dt.database_id) <> ''MANAGEMENT''
ORDER BY st.session_id  

SELECT @Rowsreturn =@@ROWCOUNT

SET @HTML=@HTML+''</TABLE></BR>Thanks </BR><B>Datavail Corporation</B>''
PRINT @HTML
SET @Subject = ''Long Running Open Tranaction '' + @@SERVERNAME

IF @Rowsreturn>0
begin
EXEC msdb..sp_send_dbmail @profile_name = ''HMDX_DBmail''
,@recipients = ''KWoods@ntst.com;harnish.desai@datavail.com;manish.trivedi@datavail.com''
, @subject = @Subject 
, @body = @HTML
, @body_format = ''HTML''
end

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170904, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'd3368364-846a-46b2-8655-8114e9203440'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_Missing_DIFF_Backup]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_Missing_DIFF_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job sends list of databases for which DIFF backup is not done in last 12 Hours. This job can be rerun', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Missing_DIFF_Backup]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Missing_DIFF_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF OBJECT_ID(''tempdb..#Temp'') IS NOT NULL
    DROP TABLE #Temp

SELECT x.database_name, z.physical_device_name, 
CONVERT(char(20), x.backup_finish_date, 108) FinishTime, x.backup_finish_date 
into #Temp
        from msdb.dbo.backupset x
JOIN ( SELECT a.database_name, max(a.backup_finish_date) backup_finish_date 
        FROM msdb.dbo.backupset a 
        WHERE type = ''I'' 
        GROUP BY a.database_name ) y on x.database_name = y.database_name 
        and x.backup_finish_date = y.backup_finish_date
        JOIN msdb.dbo.backupmediafamily z ON x.media_set_id = z.media_set_id 
order by x.backup_finish_date desc


Declare @Rowcount int

select @Rowcount  = count(*)
from #Temp T join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 30
and state = 0
and recovery_model = 1

if @Rowcount > 0
Begin

declare @tableHTML varchar(max)

	SET @tableHTML =
	N''<table border =1>'' +
	N''<tr><th>Database Name</th>
	<th>Backup Location</th>
	<th>Last Backup Finish Time</th>
	<th>Last Backup finish Date</th>	
	</tr>'' +
	CAST ( (
	SELECT td = database_name,'''',
	td = physical_device_name,'''',
	td = FinishTime,'''',
	td = backup_finish_date,''''	
	from #Temp T
       join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 30
       and state = 0
      and recovery_model = 1
	FOR XML PATH(''tr''), TYPE
	) AS NVARCHAR(MAX) ) +
	N''</table>''

--print @tableHTML

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name =''HMDX_DBMail'',
		@from_address =  ''SNDB01-SNSERVER01@healthmedx.com'' ,	
		@recipients=''sql@datavail.com'',
		@copy_recipients= ''datacenter@healthmedx.com;sql@datavail.com'',
		@subject = ''DIFF Backups Missing in last 24 hour'',
		@body = @tableHTML,
		@body_format = ''HTML'' ;

End', 
		@database_name=N'master', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180328, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'e06dcb26-a392-4de1-90eb-81ee7fac8126'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_Missing_Tlog_Backup]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_Missing_Tlog_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job sends list of databases for which log backup is not done in last 15 minutes. This job can be rerun', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Missing_Tlog_Backup]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Missing_Tlog_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF OBJECT_ID(''tempdb..#Temp'') IS NOT NULL
    DROP TABLE #Temp

SELECT x.database_name, z.physical_device_name, 
CONVERT(char(20), x.backup_finish_date, 108) FinishTime, x.backup_finish_date 
into #Temp
        from msdb.dbo.backupset x
JOIN ( SELECT a.database_name, max(a.backup_finish_date) backup_finish_date 
        FROM msdb.dbo.backupset a 
        WHERE type = ''L'' 
        GROUP BY a.database_name ) y on x.database_name = y.database_name 
        and x.backup_finish_date = y.backup_finish_date
        JOIN msdb.dbo.backupmediafamily z ON x.media_set_id = z.media_set_id 
order by x.backup_finish_date desc


Declare @Rowcount int

select @Rowcount  = count(*)
from #Temp T join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 1
and state = 0
and recovery_model = 1

if @Rowcount > 0
Begin

declare @tableHTML varchar(max)

	SET @tableHTML =
	N''<table border =1>'' +
	N''<tr><th>Database Name</th>
	<th>Backup Location</th>
	<th>Last Backup Finish Time</th>
	<th>Last Backup finish Date</th>	
	</tr>'' +
	CAST ( (
	SELECT td = database_name,'''',
	td = physical_device_name,'''',
	td = FinishTime,'''',
	td = backup_finish_date,''''	
	from #Temp T
       join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 1
       and state = 0
       and recovery_model = 1
	FOR XML PATH(''tr''), TYPE
	) AS NVARCHAR(MAX) ) +
	N''</table>''

--print @tableHTML

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name =''HMDX_DBMail'',
		@from_address =  ''SNDB01-SNSERVER01@healthmedx.com'' ,	
		@recipients=''sql@datavail.com'',
		@copy_recipients= ''datacenter@healthmedx.com;sql@datavail.com'',
		@subject = ''Log Backups Missing in last 24 hour'',
		@body = @tableHTML,
		@body_format = ''HTML'' ;

End', 
		@database_name=N'master', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180328, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'e06dcb26-a392-4de1-90eb-81ee7fac8126'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_SQL_Login_Audit]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_SQL_Login_Audit', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Login_audit]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Login_audit', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(''tempdb..#audittemp'') IS NOT NULL DROP TABLE #audittemp
create table #audittemp(server_principal_name varchar(100),event_time varchar(25),address varchar(100));

IF OBJECT_ID(''tempdb..#tmp'') IS NOT NULL DROP TABLE #tmp
CREATE TABLE #tmp (data NVARCHAR(500))

Declare @Dir VARCHAR(256), @CMD VARCHAR(256)
SET @Dir = ''f:\MSSQL10_50.SNSERVER01\MSSQL\Log\''
SET @CMD = ''DIR "''+@DIR+''" /A /S''

INSERT #tmp EXEC master..xp_cmdshell @cmd
DELETE FROM #tmp WHERE data IS NULL
DELETE FROM #tmp WHERE data NOT LIKE ''%.sqlaudit''

select RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) AS [file_name],GETDATE()
 from #tmp where REPLACE(SUBSTRING(data,22,17),'','','''') > 0 and RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) not in (select filename from Login_audit_fileprocessed)
 
 IF (@@ROWCOUNT > 0)
    BEGIN

Declare @filename varchar(300)
Declare @sql varchar(max)
 declare display CURSOR for  
 select RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) AS [file_name]
 from #tmp where REPLACE(SUBSTRING(data,22,17),'','','''') > 0 and RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) not in (select filename from Login_audit_fileprocessed)
 
		open display 
		fetch next from display into @filename
			while (@@fetch_status = 0)
			BEGIN 
							
				set @sql = 
				''WITH XMLNAMESPACES(DEFAULT ''+CHAR(39)+''http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data''+CHAR(39)+'')
				INSERT INTO #audittemp
				SELECT	server_principal_name,
				CONVERT(VARCHAR(16),event_time),
				CAST(additional_information AS xml).value(''+CHAR(39)+''(action_info/address/text())[1]''+CHAR(39)+'', ''+CHAR(39)+''varchar(255)''+CHAR(39)+'') as address
				FROM	sys.fn_get_audit_file (''+CHAR(39)+@Dir +''\''+@filename+CHAR(39)+'',default,default)''
				
				exec (@sql)

				Insert into login_audit 
				select distinct * from #audittemp where  
				address not in (select distinct IPAddress from [MANAGEMENT].[dbo].[AllowedClientIPs]);					
				
				Insert into Login_audit_fileprocessed values (@filename,GETDATE())
								
				truncate table #audittemp
				fetch next from display into @filename
			END
		CLOSE display
		deallocate display

END
', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily every 30mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=30, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150828, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b8d472fb-e3e6-4954-9294-8c0e77430713'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_suspend_and_resume_HUNG_mirroing]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_suspend_and_resume_HUNG_mirroing', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [step]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'step', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--- created by Jayvant dt : 09/04/2015
--  Purpose : script will resume the mirroring which stuck due to high unsent log.

use master

declare @DBName varchar(255)
declare @cmd varchar(255)
declare @Threshold numeric	--- @Threshold valud should by in KB
set @Threshold = 5242880

declare curM cursor static for 
	SELECT  LTRIM(RTRIM( [instance_name])) as DBName 
	FROM sys.dm_os_performance_counters
	WHERE   [object_name] LIKE (''%Database Mirroring%'') AND [counter_name] IN (''Log Send Queue KB'')
	and  LTRIM(RTRIM( [instance_name]))  in ( SELECT  db_name(sd.database_id) AS DBName FROM sys.database_mirroring AS sd WHERE mirroring_guid IS NOT null and sd.mirroring_state_desc <> ''SYNCHRONIZING'' )               
	and [instance_name] <> ''_Total'' and [cntr_value] > @Threshold

open curM
fetch next from curM into @dbname
while @@FETCH_STATUS = 0
begin
	set @cmd = 	''alter database '' +QUOTENAME(@dbname)+ '' set partner suspend''
	--print @cmd
	exec(@cmd)
	WAITFOR DELAY ''00:00:01''
	
	set @cmd = 	''alter database '' +QUOTENAME(@dbname)+ '' set partner resume''
	--print @cmd
	exec(@cmd)
	fetch next from curM into @dbname
end	
	
close curM
deallocate curM', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'every10mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150904, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'4dab24eb-43d0-405c-b86e-08f985958057'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DV_WeeklyTopSQL]    Script Date: 11/27/2018 6:22:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:22:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_WeeklyTopSQL', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [WeeklyTopSQL]    Script Date: 11/27/2018 6:22:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'WeeklyTopSQL', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'use MANAGEMENT 
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''dbo.WeeklyTopSQL'') AND TYPE IN (N''U''))
drop table MANAGEMENT.dbo.WeeklyTopSQL
go
use master 
exec dbo.sp_BlitzCache @top = 10, @sort_order  = ''CPU'',  @export_to_excel = 1,@output_database_name=''MANAGEMENT'', @output_schema_name=''dbo'', @output_table_name=''WeeklyTopSQL''
go
INSERT INTO [SNSQL05\SNSERVER05].[MANAGEMENT].[dbo].[WeeklyTopSQL]
select * from MANAGEMENT.dbo.WeeklyTopSQL', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'WeeklyTopSQL', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=8, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150428, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959, 
		@schedule_uid=N'6a741c08-52bd-43fd-bd20-55615256b6de'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

