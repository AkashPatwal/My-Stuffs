set nocount on 

use msdb
--drop TABLE #HTMLCode
CREATE TABLE #HTMLCode
(
 Code VARCHAR(MAX)
)

BULK INSERT #HTMLCode
   FROM 'C:\dv\DV_RDP\RDP_Report.html' ;
   
   
   ---Select Code from #HTMLCode 
   
   DECLARE @text VARCHAR(MAX),@text1 VARCHAR(MAX)
   set @text = ''
--   select * from #HTMLCode
   Select @text=isnull(@text,'')+isnull(code,'')+CHAR(10) from #HTMLCode
print @text

      --Select code from #HTMLCode for xml path (''),type
         
   exec msdb.dbo.sp_send_dbmail  @profile_name='DBA',
@subject='Mammoth Open RDP Sessions Report  ',
--  @recipients='shashidhar.mankala@datavail.com'
  @recipients='dv-sqlteam2@datavail.com',
  @copy_recipients='Anup.Gopinathan@datavail.com;dpeterson@mammoth-mtn.com'
,@body=@text,
   @body_format = 'HTML',@file_attachments ='C:\dv\DV_RDP\RDP_Report.html'