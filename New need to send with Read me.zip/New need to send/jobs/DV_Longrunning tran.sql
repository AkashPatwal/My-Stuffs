USE [msdb]
GO

/****** Object:  Job [DV_LongRunningTransaction]    Script Date: 11/27/2018 6:31:06 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:31:06 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_LongRunningTransaction', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Report]    Script Date: 11/27/2018 6:31:06 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Report', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @HTML VARCHAR(MAX),
@Subject VARCHAR(500),
@DBAMsg Varchar(500),
@ReportTitle Varchar(1000),
@threshold int,
@Rowsreturn int

SELECT @ReportTitle= convert(varchar(50),@@SERVERNAME)+'':: LONG RUNNNING TRANSACTION REPORT''
,@threshold=120 -- Please specify in minutes
,@ReportTitle=''<font size="4"><B>''+ltrim(rtrim(@ReportTitle))+''</B></font></BR>''
,@DBAMsg=''<html><body></BR> Hello Team </BR><BR>Please look into the below report for LONG RUNNING OPEN TRANSACTION</BR>''
 
--''<td valign="top">''+ CONVERT(VARCHAR(15), ISNULL(dt.database_transaction_begin_time, 0),101) + '' '' + CONVERT(VARCHAR(15), ISNULL(dt.database_transaction_begin_time, 0), 14) +
SET @HTML = ''<html><body>'' --<table border = 1>
+@ReportTitle
+ltrim(rtrim(@DBAMsg))+
''<table border = 1><tr style="background-color:Orange; height:20px;">
<th>Session ID</th>
<th>Database Name</th>
<th>Open_Tran</th>
<th>Transaction Type</th>
<th>Transaction Time</th>
<th>Individual Query</th>
<th>HostName</th>
<th>User</th>
<th>LoginName</th>
<th>Parent Query</th>
<th>Start Time</th>
<th>Status</th>
<th>ECID</th>
<th>Wait</th>
<th>Transaction Log record count</th>
<th>Transaction Log bytes used</th>
</tr>''

SET NOCOUNT ON--+--CASE WHEN dt.database_transaction_begin_time IS NULL THEN ''read-only'' ELSE ''read-write'' END +
SELECT @HTML = @HTML + ''<p><tr ><td valign="top"></p>''+ Cast(st.session_id as Varchar(10)) + 
''<td valign="top">''+ CASE WHEN dt.database_id = 32767 then ''resourceDb'' else DB_NAME(dt.database_id) end +
''<td valign="top">''+ convert(varchar(5),Qry.open_tran)+
''<td valign="top">''+ CASE  dt.database_transaction_type WHEN 1 then ''Read/write'' 
WHEN 2 then ''Read-only''
WHEN 3 then ''System''  
ELSE ''''
END+
''<td valign="top">''+ ltrim(rtrim(convert(varchar(20),dt.database_transaction_begin_time)))+
''<td valign="top">''+ SUBSTRING(Qry.[Individual Query], 1, 2000) +
''<td valign="top">''+ Qry.hostname +
''<td valign="top">''+ Qry.[User] +
''<td valign="top">''+ Qry.[loginame] +
''<td valign="top">''+ SUBSTRING(Qry.[Parent Query],1,2000) +
''<td valign="top">''+ CONVERT(VARCHAR(15), ISNULL(Qry.start_time, 0),101) + '' '' + CONVERT(VARCHAR(15), ISNULL(Qry.start_time, 0), 14) +
''<td valign="top">''+ Qry.Status + 
''<td valign="top">''+ CAST(ISNULL(ecid,0) as Varchar(10)) +
''<td valign="top">''+ CAST(ISNULL(Qry.Wait,0) as Varchar(10)) +
''<td valign="top">''+ CAST(dt.database_transaction_log_record_count as Varchar(20)) +
''<td valign="top">''+ CAST(dt.database_transaction_log_bytes_used as Varchar(20)) +
''</tr>''
FROM sys.dm_tran_session_transactions AS st 
INNER JOIN sys.dm_tran_database_transactions AS dt ON st.transaction_id = dt.transaction_id
JOIN (
SELECT [Spid] = session_Id
,ecid
,sp.open_tran as open_tran
,[Database] = DB_NAME(sp.dbid)
,[User] = nt_username
,sp.loginame
,[Status] = er.status
,[Wait] = wait_type
,[Individual Query] = SUBSTRING (qt.text, 
er.statement_start_offset/2,
(
CASE WHEN er.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX), qt.text)) * 2 
ELSE er.statement_end_offset END - 
er.statement_start_offset)/2)
,[Parent Query] = qt.text
, Program = program_name
, Hostname
, nt_domain
, start_time
--select * sys.sysprocesses
FROM  sys.dm_exec_requests er
LEFT JOIN sys.sysprocesses sp ON er.session_id = sp.spid
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle)as qt
WHERE session_Id > 50 -- Ignore system spids.
AND session_Id NOT IN (@@SPID) -- Ignore this current statement.
AND qt.text not like ''%WAITFOR(RECEIVE%''
---- Added above line to exclude this message ----
) Qry on st.session_id = Qry.Spid
WHERE DATEDIFF(mi, dt.database_transaction_begin_time,getdate() ) > @threshold AND dt.database_transaction_begin_time IS NOT NULL
And DB_NAME(dt.database_id) <> ''MANAGEMENT''
ORDER BY st.session_id  

SELECT @Rowsreturn =@@ROWCOUNT

SET @HTML=@HTML+''</TABLE></BR>Thanks </BR><B>Datavail Corporation</B>''
PRINT @HTML
SET @Subject = ''Long Running Open Tranaction '' + @@SERVERNAME

IF @Rowsreturn>0
begin
EXEC msdb..sp_send_dbmail @profile_name = ''HMDX_DBmail''
,@recipients = ''KWoods@ntst.com;harnish.desai@datavail.com;manish.trivedi@datavail.com''
, @subject = @Subject 
, @body = @HTML
, @body_format = ''HTML''
end

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170904, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'd3368364-846a-46b2-8655-8114e9203440'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

