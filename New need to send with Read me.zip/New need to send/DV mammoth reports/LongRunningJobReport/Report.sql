--select 
--	case	when s.type = 'D' then d.name
--			when s.type = 'I' then '-- ' + d.name
--			when s.type = 'L' then '---- ' + d.name else d.name
--	end,
--	isnull(s.physical_device_name, 'database(s) never backed up.'), -- max(substring(z.physical_device_name, 0, len(z.physical_device_name) + 2 - charindex('\', reverse(z.physical_device_name), 0)))  {to get the file path only}
--	convert(char(20), s.backup_finish_date, 108) finishtime,
--	s.backup_finish_date,
--	datediff(mi, s.backup_finish_date, getdate()),
--	isnull(s.type, 'XXX') as bkptype
--from sys.databases d
--left join
--	(	select x.backup_finish_date, x.database_name, y.type, z.physical_device_name
--		from
--			msdb.dbo.backupset x --on d.name = x.database_name
--		join
--			( select a.database_name, type, max(a.backup_finish_date) backup_finish_date, max(backup_set_id) backup_set_id
--					from msdb.dbo.backupset a     --where type = 'd'
--					group by a.database_name, type  --order by 1
--			) y on x.backup_set_id = y.backup_set_id 
--		join 
--			msdb.dbo.backupmediafamily z on x.media_set_id = z.media_set_id 
--	) s on d.name = s.database_name
--group by d.name, s.backup_finish_date, s.type, physical_device_name
--order by d.name asc, s.type asc, s.backup_finish_date desc


set nocount on

use master

------------------------------Declarations-----------------------------------------------------
declare	@sbody varchar(max)
declare	@sdata varchar(max)
declare @durr int
declare @excJOBlist varchar(1000)

-- Applying the values passed by Powershell script
select @durr = $(durr), @excJOBlist = $(excJOBlist)

-- For testing purpose on SSMS
--select @durr = 1, @excJOBlist = ''
--select @durr, @excJOBlist

------------------------------Converting comma separated values to rows-----------------------------------------------------
if object_id('tempdb..#list') is not null
	drop table #list
	 
create table #list (item varchar(200))

set @excJOBlist = @excJOBlist + ',';
with nbrs_3(n) as (select 1 union select 0),
	nbrs_2(n) as (select 1 from nbrs_3 n1 cross join nbrs_3 n2) ,
	nbrs_1(n) as (select 1 from nbrs_2 n1 cross join nbrs_2 n2),
	nbrs_0(n) as (select 1 from nbrs_1 n1 cross join nbrs_1 n2),
	nbrs  (n) as (select 1 from nbrs_0 n1 cross join nbrs_0 n2)
insert into #list
select substring(@excJOBlist, n+1, charindex(',', @excJOBlist, n+1) - n-1)
from
(
	select 0 as 'n' 
	union all 
	select top(len(@excJOBlist)-1) row_number() over (order by n) as 'n'
    from nbrs
) x
where substring(@excJOBlist, n, 1) = ',' or n = 0

------------------------------Converting table into HTML script-----------------------------------------------------
set @sbody = '<html><body><br><table width="100%" border=1 align="center" cellpadding="1" cellspacing="0"><tr bgcolor="#b8944d"><th colspan="5" cellspacing="1"><font face="segoe ui" size="2">' + Upper(@@servername) + '</font><font face="segoe ui" size="1"> {thresholds Duration:' + cast(@durr as varchar) + '}</font></th>' +
'<tr bgcolor="#9d9da9">' +
	'<th width=10%> <font face="segoe ui" size="1.5">SESSION ID</font></th>' +
	'<th width=5%> <font face="segoe ui" size="1.5">JOB NAME</font></th>' +
	'<th width=5%> <font face="segoe ui" size="1.5">PROGRAM NAME</font></th>' +
	'<th width=5%> <font face="segoe ui" size="1.5">DURATION (in minutes)</font></th>' +
	'<th width=5%> <font face="segoe ui" size="1.5">RUNNING SINCE</font></th>' +
'</tr>'

select  @sdata =  ISNULL(@sdata, '') +
		'<tr bgcolor="#B8B8B8">' +
			'<td><font face="segoe ui" size="1">' + cast(isnull(spid, 0) as varchar(5)) + '</font></td>' +
			'<td><font face="segoe ui" size="1">' + isnull(J.Name, '--') + '</font></td>' +
			'<td><font face="segoe ui" size="1">' + cast(isnull(program_name, '') as varchar(5)) + '</font></td>' +
			'<td><font face="segoe ui" size="1">' + convert(varchar, ISNULL(DATEDIFF(MI, P.LOGIN_TIME, GETDATE()), 0)) + '</font></td>' +
			'<td><font face="segoe ui" size="1">' + convert(varchar, P.LOGIN_TIME, 121) + '</font></td>' +
		'</tr>'
--Select spid, program_name, j.name, p.login_time, convert(varchar, ISNULL(DATEDIFF(MI, P.LOGIN_TIME, GETDATE()), 0))
FROM MASTER..SYSPROCESSES P (NOLOCK) 
	JOIN msdb..sysjobs J (NOLOCK) ON  
		SUBSTRING(LEFT(J.JOB_ID,8),7,2) + SUBSTRING(LEFT(J.JOB_ID,8),5,2) +   SUBSTRING(LEFT(J.JOB_ID,8),3,2) + SUBSTRING(LEFT(J.JOB_ID,8),1,2) = SUBSTRING(P.PROGRAM_NAME,32,8) 
WHERE	J.name not in (select item from #list)
	AND	ISNULL(DATEDIFF(MI, P.LOGIN_TIME, GETDATE()), 0) >= @durr 

if (@@ROWCOUNT < 1)
begin
	select  @sdata = NULL --'<tr bgcolor="#ff3333"><td>No data found</td></tr>' 
end

set @sbody = @sbody + @sdata + '</table><br><br></body></html>'
select @sbody as col


--DECLARE @tableHTML  VARCHAR(MAX) ;  
--SET @tableHTML =  
--    N'<font face ="Calibri" size=2><H3 background-color : #405050;>Long Running Job Report for Server :'+@@servername+'</H3>' +  
--    N'<table border="1" align="center"><font face ="Calibri" size=2>' +  
--    N'<tr bgcolor="#FFE4B5"><th>SPID</th><th>JobName</th>' +  
--    N'<th>PROGRAM_NAME</th><th>MINUTES SINCE RUNNING</th>' +  
--    N'<th>START TIME</th>' +  
--    CAST (   (  

--SELECT td = P.SPID,'',
--                    td = J.Name,'',
--                    td = PROGRAM_NAME,'',
--                    td = convert(varchar,ISNULL(DATEDIFF(MI, P.LOGIN_TIME, GETDATE()), 0)),'',
--                    td = LOGIN_TIME,''
--              FROM MASTER..SYSPROCESSES P  
-- JOIN msdb..sysjobs J ON  
--SUBSTRING(LEFT(J.JOB_ID,8),7,2) + SUBSTRING(LEFT(J.JOB_ID,8),5,2) +   SUBSTRING(LEFT(J.JOB_ID,8),3,2) + SUBSTRING(LEFT(J.JOB_ID,8),1,2) = 
--SUBSTRING(P.PROGRAM_NAME,32,8)  
----WHERE J.name in ('DBA Index Maintenance','DBA Integrity Check','DV_Update_Statistics_Job','DV_Test Longrunning job')
--FOR XML PATH('tr'), TYPE   
--    ) AS NVARCHAR(MAX) ) +  
--    N'</font></table></font>' ;  
      
--Select @tableHTML 