/*********************************************************
-- Created by: 		Anup Gopinathan (datavail)
-- Created date:	02/27/2015
-- Description:		To generate backup report for multiple servers. 
			This sql file is executed on multiple servers using powershell scripts. 
			Based on threshold values the backup are checked and highlighted if there a breach.
-- Modified Date:	06/13/2016
-- Modification:	Modifies the script to be run on High Availibility groups databases.
			The script will verify if the server is HAG enabled, if it is,
			it check if the current server is the prefered backup sever, if not the databases are skipped from backup verification.
*********************************************************/

set nocount on

use master

------------------------------Declarations-----------------------------------------------------
declare	@sbody varchar(max)
declare @full int
declare @diff int
declare @tlog int
declare @AAG_REPORTING varchar(20)
declare @excdblist varchar(1000)
Declare @getversion smallint = Case when charindex('.', Convert(varchar, SERVERPROPERTY('productversion'))) - 1 > 0 then substring(Convert(varchar, SERVERPROPERTY('productversion')), 1, charindex('.', Convert(varchar, SERVERPROPERTY('productversion'))) - 1) else 0 end
DECLARE @ServerName NVARCHAR(256)  = @@SERVERNAME 
DECLARE @RoleDesc NVARCHAR(60)

-- Applying the values passed by Powershell script
select @full = $(full), @diff = $(diff), @tlog = $(tlog), @excdblist = $(excDBlist)

-- For testing purpose on SSMS
--select @full = 1000 , @diff = 10000 , @tlog = 30, @AAG_REPORTING = 'Secondary' , @excdblist = ''
--select @full, @diff, @tlog, @AAG_REPORTING, @excdblist

------------------------------Converting comma separated values to rows-----------------------------------------------------
if object_id('tempdb..#dblist') is not null
	drop table #dblist
	 
create table #dblist (db varchar(200))

set @excdblist = @excdblist + ',';
with nbrs_3(n) as (select 1 union select 0),
	nbrs_2(n) as (select 1 from nbrs_3 n1 cross join nbrs_3 n2) ,
	nbrs_1(n) as (select 1 from nbrs_2 n1 cross join nbrs_2 n2),
	nbrs_0(n) as (select 1 from nbrs_1 n1 cross join nbrs_1 n2),
	nbrs  (n) as (select 1 from nbrs_0 n1 cross join nbrs_0 n2)
insert into #dblist
select substring(@excdblist, n+1, charindex(',', @excdblist, n+1) - n-1)
from
(
	select 0 as 'n' 
	union all 
	select top(len(@excdblist)-1) row_number() over (order by n) as 'n'
    from nbrs
) x
where substring(@excdblist, n, 1) = ',' or n = 0

insert into #dblist values ('tempdb') -- excluding tempdb, as it is never backed up.


------------------------------Getting the data to staging table-----------------------------------------------------
if object_id('master..dv_bkpreport_fordb_05022016') is not null
begin
	drop table master..dv_bkpreport_fordb_05022016
end

create table master..dv_bkpreport_fordb_05022016
(
		dbname					varchar(200)	collate sql_latin1_general_cp1_ci_as
	,	dbrec					varchar(20)		collate sql_latin1_general_cp1_ci_as
	,	dbstatus				varchar(20)		collate sql_latin1_general_cp1_ci_as
	,	bkppath					varchar(2000)	collate sql_latin1_general_cp1_ci_as
	,	bkpdate					datetime
	,	bkpretn					int
	,	bkptype					varchar(5)		collate sql_latin1_general_cp1_ci_as
	,	backup_size				varchar(30)
	,	compressed_backup_size	varchar(30)
	,	backup_duration			varchar(30)		collate sql_latin1_general_cp1_ci_as
	,	bkpfull					int
	,	bkpdiff					int
	,	bkptlog					int
	,	dispseq					tinyint
	,	aagPreferedreplica		bit
	,	isCopyOnly				varchar(3)
)

-----Checking for High Availability Group replica role-----------------------------------------------------

if @getversion > 10
	BEGIN
		insert into master..dv_bkpreport_fordb_05022016
		select  
				d.name as dbname
			,	d.recovery_model_desc as dbrec
			,	d.state_desc
			,	isnull(s.physical_device_name, 'database(s) never backed up.') as bkppath -- 
			,	s.backup_finish_date as bkpdate
			,	case when s.backup_finish_date is null then 9999999 else datediff(mi, s.backup_finish_date, getdate()) end as bkpretn
			,	isnull(s.type, 'FULL') as bkptype
			,	CAST(coalesce(nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),4) as bigint),0),
                        nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),3) as bigint),0),
                        nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),2) as bigint),0),
                        nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),1) as bigint),0), 
                        isnull(backup_size, 0)
                        ) as varchar(21)) +
				coalesce(' TB' + space(nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),4) as bigint),0)), 
                   ' GB' + space(nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),3) as bigint),0)), 
                   ' MB' + space(nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),2) as bigint),0)), 
                   ' KB' + space(nullif(Cast(isnull(backup_size, 0)/power(cast(1024 as bigint),1) as bigint),0)), 
                   ' Bytes'
                  ) as backup_size
			,	CAST(coalesce(nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),4) as bigint),0),
                        nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),3) as bigint),0),
                        nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),2) as bigint),0),
                        nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),1) as bigint),0), 
                        isnull(compressed_backup_size, 0)
                        ) as varchar(21)) +
				coalesce(' TB' + space(nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),4) as bigint),0)), 
                   ' GB' + space(nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),3) as bigint),0)), 
                   ' MB' + space(nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),2) as bigint),0)), 
                   ' KB' + space(nullif(Cast(isnull(compressed_backup_size, 0)/power(cast(1024 as bigint),1) as bigint),0)), 
                   ' Bytes'
                  ) as compressed_backup_size
			,	backup_duration
			,	@full as bkpfull
			,	@diff as bkpdiff
			,	@tlog as bkptlog
			,	case	when s.type = 'FULL' then 1
						when s.type = 'DIFF' then 2
						when s.type = 'LOG'  then 3
						when s.type IS NULL  then 4
				end as dispseq
			,	case when replica_id is null then 0 else 1 end as aagPreferedreplica
			,	case when is_copy_only = 1 then 'Yes' else 'No' end is_copy_only
		from sys.databases d (NOLOCK)
		left join #dblist l on d.name = l.db
		left join 
			(	select	x.backup_finish_date
					,	x.database_name
					,	case	when y.type = 'D' then 'FULL'
								when y.type = 'I' then 'DIFF'
								when y.type = 'L' then 'LOG'
								when y.type is null then 'FULL'
						end as [type]
					,	backup_size
					,	compressed_backup_size
					,	case when datediff(mi, x.backup_start_date, x.backup_finish_date) < 1 then '< 1 minute ' else cast(datediff(mi, x.backup_start_date, x.backup_finish_date) as varchar(20)) + ' minutes' end backup_duration
					,	z.physical_device_name --max(substring(z.physical_device_name, 0, len(z.physical_device_name) + 2 - charindex('\', reverse(z.physical_device_name), 0))) as bkppath --  {to get the file path only}
					,	is_copy_only
				from
					msdb.dbo.backupset x (NOLOCK) --on d.name = x.database_name
				join
					( select a.database_name, type, max(a.backup_finish_date) backup_finish_date, max(backup_set_id) backup_set_id
							from msdb.dbo.backupset a (NOLOCK)   --where type = 'd'
							group by a.database_name, type  --order by 1
					) y on x.backup_set_id = y.backup_set_id 
				join 
					msdb.dbo.backupmediafamily z (NOLOCK) on x.media_set_id = z.media_set_id 
			) s on d.name = s.database_name
		where 1 = 1
			and l.db is null and state_desc ='ONLINE' and source_database_id is  null
			and sys.fn_hadr_backup_is_preferred_replica(d.name) = 1
		--group by d.name, d.recovery_model_desc,	d.state_desc, s.backup_finish_date, s.type, s.physical_device_name,	backup_size
			--,	compressed_backup_size
			--,	backup_duration
	END
else -- Legacy servers -- version prior to SQL server 2012
	BEGIN
		insert into master..dv_bkpreport_fordb_05022016
		select  
				d.name as dbname
			,	d.recovery_model_desc as dbrec
			,	d.state_desc
			,	isnull(s.physical_device_name, 'database(s) never backed up.') as bkppath -- 
			,	s.backup_finish_date as bkpdate
			,	datediff(mi, isnull(s.backup_finish_date, getdate()), getdate()) as bkpretn
			,	isnull(s.type, 'FULL') as bkptype
			,	backup_size
			,	compressed_backup_size
			,	backup_duration
			,	@full as bkpfull
			,	@diff as bkpdiff
			,	@tlog as bkptlog
			,	case	when s.type = 'FULL' then 1
						when s.type = 'DIFF' then 2
						when s.type = 'LOG'  then 3
						when s.type IS NULL  then 4
				end as dispseq
			,	1 as aagPreferedreplica
			,	'No' as is_copy_only
		from sys.databases d 
		left join #dblist l on d.name = l.db
		left join 
			(	select	x.backup_finish_date
					,	x.database_name
					,	case	when y.type = 'D' then 'FULL'
								when y.type = 'I' then 'DIFF'
								when y.type = 'L' then 'LOG'
								when y.type is null then 'FULL'
						end as [type]
					,	backup_size
					,	compressed_backup_size
					,	case when datediff(mi, x.backup_start_date, x.backup_finish_date) < 1 then '< 1 minute ' else cast(datediff(mi, x.backup_start_date, x.backup_finish_date) as varchar(20)) + ' minutes' end backup_duration
					,	z.physical_device_name --max(substring(z.physical_device_name, 0, len(z.physical_device_name) + 2 - charindex('\', reverse(z.physical_device_name), 0))) as bkppath --  {to get the file path only}
				from
					msdb.dbo.backupset x --on d.name = x.database_name
				join
					( select a.database_name, type, max(a.backup_finish_date) backup_finish_date, max(backup_set_id) backup_set_id
							from msdb.dbo.backupset a     --where type = 'd'
							group by a.database_name, type  --order by 1
					) y on x.backup_set_id = y.backup_set_id 
				join 
					msdb.dbo.backupmediafamily z on x.media_set_id = z.media_set_id 
			) s on d.name = s.database_name
		where 1 = 1
			and l.db is null and state_desc ='ONLINE' and source_database_id is  null
		group by d.name, d.recovery_model_desc,	d.state_desc, s.backup_finish_date, s.type, s.physical_device_name,	backup_size
			,	compressed_backup_size
			,	backup_duration
	END

--	insert into master..dv_bkpreport_fordb_05022016
--	Select
--		a.dbname
--	,	a.dbrec
--	,	a.dbstatus
--	,	isnull(b.bkppath, 'database(s) never backed up.') as bkppath
--	,	b.bkpdate
--	,	999999 bkpretn
--	,	'LOG' as bkptype
--	,	b.backup_size
--	,	b.compressed_backup_size
--	,	b.backup_duration
--	,	b.bkpfull
--	,	b.bkpdiff
--	,	b.bkptlog
--	,	b.dispseq
--	,	b.aagPreferedreplica
--from  master..dv_bkpreport_fordb_05022016 a
--left join 
--(
--	Select * from master..dv_bkpreport_fordb_05022016 b 
--	where b.dbrec = 'FULL' and b.bkptype = 'LOG') b on a.dbname = b.dbname
--where a.dbrec = 'FULL' and a.bkptlog > 0 and b.dbname is null

------------------------------Converting table into HTML script-----------------------------------------------------
set @sbody = '<html><body><br><table width="100%" border=1 align="center" cellpadding="1" cellspacing="0"><tr bgcolor="#7ac5cd"><th colspan="6" cellspacing="1"><font face="segoe ui" size="4">' + Upper(@@servername) + '</font><font face="segoe ui" size="2"> {thresholds full:' + cast(@full as varchar) + ' diff:' + cast(@diff as varchar) + ' tlogs:' + cast(@tlog as varchar) + '}</font></th><tr bgcolor="#a2cd5a"><th width=25%> <font face="segoe ui" size="3">DATABASE</font></th><th width=25%> <font face="segoe ui" size="3">FULL BACKUP</font></th><th width=25%> <font face="segoe ui" size="3">DIFFERENTIAL BACKUP</font></th><th width=25%> <font face="segoe ui" size="3">LOG BACKUP</font></th></tr>'


IF (select count(1) from master..dv_bkpreport_fordb_05022016)< 1
	BEGIN
		SELECT @sbody =  @sbody + '<tr><td bgcolor="#c8c8c8"><font face="segoe ui" size="1"> No data Avaialble </td></tr>'
		select @sbody as col
		RETURN;
	END

SELECT @sbody =  @sbody + '<tr><td' + db + '</td><td ' + ISNULL(MAX(fullKP),'') + '</td><td ' + ISNULL(MAX(DIFFBKP), '') + '</td><td ' + ISNULL(MAX(TLOGBKP), '') + '</td></tr>'
--SELECT db, MAX(fullKP) , MAX(DIFFBKP) , MAX(TLOGBKP) , MAX(XXXXBKP)
FROM
	(
		select dbname, bkpdate, bkptype, bkpretn, dispseq,
			' bgcolor="#c8c8c8"><font face="segoe ui" size="3"><b>' + cast(isnull(dbname, '??') as varchar(200)) + '</b></font><br><font face="segoe ui" size="1"><b>Recovery Model:</b> ' + cast(dbrec as varchar(20)) + '</font><br><font ' + case when cast(dbstatus as varchar(20)) <> 'ONLINE' then 'color="red"' else '' end + ' face="segoe ui" size="1"><b>Status:</b> ' + cast(dbstatus as varchar(20)) + '</font>' + char(10) db,
			' ' +
			case	
					when bkptype = 'FULL' then 'bgcolor="' + case when bkpretn > @full and @full <> 0 then '#ff3333' else '#F5F5F5' end + '"><font face="segoe ui" size="1"><b>File Path:</b> ' + isnull(max(substring(bkppath, 0, len(bkppath) + 2 - charindex('\', reverse(bkppath), 0))), 'database never backed up.') + '</font><br><font face="segoe ui" size="1"><b>File Name(s):</b> ' + '' + isnull(stuff((	select ', ' + char(10) + right(bkppath, (case when charindex('\', reverse(bkppath), 0) >0 then (charindex('\', reverse(bkppath), 0)-1) else 0 end)) from master..dv_bkpreport_fordb_05022016 b1 where b1.dbname = b.dbname and b1.bkptype = 'FULL' for xml path('')),1,1,''), '') + '</font><br><font face="segoe ui" size="2"><b>Backup Date:</b> ' + isnull(convert(varchar(20), bkpdate, 121), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Duration:</b> ' + isnull(cast(backup_duration as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Size:</b> ' + isnull(cast(backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Compressed Backup Size:</b> ' + isnull(cast(compressed_backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Minutes since last backup:</b> ' + isnull(cast(bkpretn as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Is copy only:</b> ' + isnull(isCopyOnly, 'No') + '</font><br><font face="segoe ui" size="1"><b>Part of HAG:</b> ' + case when aagPreferedreplica = 1 then 'YES' else 'NO' end  + '</font>' + char(10)
			end AS fullKP,
			' ' +
			case	
					when bkptype = 'DIFF' then 'bgcolor="' + case when bkpretn > @diff and @diff <> 0 then '#eb5858' else '#F7F7F7' end + '"><font face="segoe ui" size="1"><b>File Path:</b> ' + isnull(max(substring(bkppath, 0, len(bkppath) + 2 - charindex('\', reverse(bkppath), 0))), 'database never backed up.') + '</font><br><font face="segoe ui" size="1"><b>File Name(s):</b> ' + '' + isnull(stuff((	select ', ' + char(10) + right(bkppath, (case when charindex('\', reverse(bkppath), 0) >0 then (charindex('\', reverse(bkppath), 0)-1) else 0 end)) from master..dv_bkpreport_fordb_05022016 b1 where b1.dbname = b.dbname and b1.bkptype = 'DIFF' for xml path('')),1,1,''), '') + '</font><br><font face="segoe ui" size="2"><b>Backup Date:</b> ' + isnull(convert(varchar(20), bkpdate, 121), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Duration:</b> ' + isnull(cast(backup_duration as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Size:</b> ' + isnull(cast(backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Compressed Backup Size:</b> ' + isnull(cast(compressed_backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Minutes since last backup:</b> ' + isnull(cast(bkpretn as varchar(20)), '--') + '</font>' + char(10)
			end AS DIFFBKP,
			' ' +
			case	
					when bkptype = 'LOG'  then 'bgcolor="' + case when bkpretn > @tlog and @tlog <> 0 then '#d79090' else '#FCFCFC' end + '"><font face="segoe ui" size="1"><b>File Path:</b> ' + isnull(max(substring(bkppath, 0, len(bkppath) + 2 - charindex('\', reverse(bkppath), 0))), 'database never backed up.') + '</font><br><font face="segoe ui" size="1"><b>File Name(s):</b> ' + '' + isnull(stuff((	select ',' + char(10) + right(bkppath, (case when charindex('\', reverse(bkppath), 0) >0 then (charindex('\', reverse(bkppath), 0)-1) else 0 end)) from master..dv_bkpreport_fordb_05022016 b1 where b1.dbname = b.dbname and b1.bkptype = 'LOG' for xml path('')),1,1,''), '') + '</font><br><font face="segoe ui" size="2"><b>Backup Date:</b> ' + isnull(convert(varchar(20), bkpdate, 121), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Duration:</b> ' + isnull(cast(backup_duration as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Backup Size:</b> ' + isnull(cast(backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Compressed Backup Size:</b> ' + isnull(cast(compressed_backup_size as varchar(20)), '--') + '</font><br><font face="segoe ui" size="1"><b>Minutes since last backup:</b> ' + isnull(cast(bkpretn as varchar(20)), '--') + '</font>' + char(10)
			end AS TLOGBKP
		from master..dv_bkpreport_fordb_05022016 b
		where 1 = 1
			and bkptype <> case when dbrec = 'simple' then 'LOG' else '' end
			and bkptype <> case when bkpfull = 0 then 'FULL' else '' end
			and bkptype <> case when bkpdiff = 0 then 'DIFF' else '' end
			and bkptype <> case when bkptlog = 0 then 'LOG' else '' end
		group by dbname, dbrec, dbstatus, bkpdate, bkptype, bkpretn, dispseq, backup_duration, backup_size, compressed_backup_size, isCopyOnly, aagPreferedreplica
		--order by b.dbname asc, dispseq asc, bkpdate desc
	) AS A
group by db

if object_id('master..dv_bkpreport_fordb_05022016') is not null
begin
	drop table master..dv_bkpreport_fordb_05022016
end

set @sbody = replace(@sbody, '<td </td>', '<td> </td>')
set @sbody = replace(@sbody, '>>', '>')
set @sbody =  @sbody + '</table><br><br></body></html>'
select @sbody as col