USE [msdb]
GO

/****** Object:  Job [Refresh STARDB Snapshot for Actuarial]    Script Date: 11/17/2018 11:09:09 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Refresh]    Script Date: 11/17/2018 11:09:09 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Refresh' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Refresh'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Refresh STARDB Snapshot for Actuarial', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'* Looks for Backups of STARDB on \\HQDBT02\Backup\HQDBT-Clstr$AG-STAR\STARDB\FULL
 - with Prefix of HQDBT-Clstr$AG-STAR_STARDB_FULL
 - most recent full
* If Valid Backup found, Copies Backup to G:\MSSQL\Backups\FromSTAR
* Creates Control File (Ext .ctl) during Copy Process
* Kicks of DROP and Restore only after file copy operation Completes
* If Backup Already copied then Exists with messages(No Drop/Restore of STARDB
* Cleanup Prod Settings ( scripts provided by TCS)
NOTE: This job should not be re', 
		@category_name=N'Database Refresh', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check if source backup is current]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check if source backup is current', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=60, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @HrsToCheckParameter INT
	, @CurrentDayName VARCHAR(20)
	, @BaseDate DATETIME
	, @FullLastModifiedDate DATETIME
	, @DiffLastModifiedDate DATETIME
	, @BaseTime TIME
	, @CurrentTime TIME
	, @CurrentDate DATE
	, @TimeDiff INT

SET @CurrentDayName = DATENAME(weekday,getdate())
SET @CurrentDate = getdate()
SET @CurrentTime = convert(time, getdate())

/* BEGIN: check for the full */
IF @CurrentDayName NOT IN (''Saturday'', ''Sunday'')
BEGIN
	SET @BaseTime = convert(time, ''00:15:00.0000000'')
	IF @CurrentDayName = ''Monday''
		SET @HrsToCheckParameter = 72
	ELSE
		SET @HrsToCheckParameter = 12
END
ELSE
BEGIN
	SET @BaseTime = convert(time, ''00:15:00.0000000'')
	SET @HrsToCheckParameter = 12
END

--IF @CurrentTime >= @BaseTime
--BEGIN
	SET @BaseDate = DATEADD(hh, -1*@HrsToCheckParameter, GETDATE())	-- SET @BaseDate = DATEADD(hh, -DATEPART(hh, GETDATE()), GETDATE())
--END
--ELSE
--BEGIN
--	SET @BaseDate = DATEADD(dd, -1, GETDATE())
--END
--SET @BaseDate = CAST(CONVERT(date, @BaseDate ) AS DATETIME) + CAST(@BaseTime AS DATETIME)


EXEC [DBAContent].[dbo].[FileCurrentCheck]
	 @MailProfile = ''DBA Mail Profile''
	, @MailTo = ''DBANotification@wcirb.com''
	, @MailCC = NULL
	, @DBAPaging = ''DBAPage@wcirb.com''
	, @SendPaging = 0
	, @SendMail = 0
	, @ShowResult = 0
	, @ItemName = ''Refresh STARDB Snapshot for Actuarial (''
	, @BodyNote = ''NOTE: ''
	, @FilePath = ''\\HQDBT02\Backup\HQDBT-Clstr$AG-STAR\STARDB\FULL''
	--, @FilePath = ''\\HQDBT02\Backup\HQDBT02\STARDB\FULL''
	, @FileName = ''HQDBT-Clstr$AG-STAR_STARDB_Full*.bak''
	--, @FileName = ''HQDBT02_STARDB_Full*.bak''
	, @HrsToCheck = @HrsToCheckParameter 
	, @Keyword = ''Full''
	, @FileAttribute = ''/A'' 
			/*
			/A          Displays files with specified attributes.   
				attributes   
				D  Directories
				R  Read-only files
				H  Hidden files               
				A  Files ready for archiving
				S  System files               -  Prefix meaning not
			*/
	,@BasisDate = @BaseDate
	,@RaiseErrorInd = 1
	,@MinNumFileExpected = 1
	,@FileLastModifiedCurrent = @FullLastModifiedDate OUTPUT 

PRINT ''Full Backup LastModifiedDate is '' + CONVERT(varchar(30), @FullLastModifiedDate, 100)
/* END: check for the full */
GO
', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Copy database backup file]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Copy database backup file', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=10, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'cd c:
#clear-Host
$ProdBackupFolderPath = ''\\HQDBT02\Backup\HQDBT-Clstr$AG-STAR\STARDB\FULL\'';
#$ProdBackupFolderPath = ''\\HQDBT02\Backup\HQDBT02\STARDB\FULL\'';
$DestFolder = ''K:\Backups\DBBackup\'';
$DestBackupFile = $DestFolder + ''STARDB_FULL.bak'';
$DaysToRetain = 1;
$FullBakupPrefix = ''HQDBT-Clstr$AG-STAR_STARDB_Full'';
#$FullBakupPrefix = ''HQDBT02_STARDB_Full'';
$ctlfilename = ''STARDB_FULL''
$ctlextension = ''ctl'';

try {
    $validpath = test-path -path $ProdBackupFolderPath

    if($validpath -eq $False) 
    {
        $txt = ''Production Backup folder missing: ''+  $ProdBackupFolderPath;
        #Write-Output  $txt;
        Throw $txt;
    }
    
    #look for files in the Bakup Location
    $FullBakupPrefix = "*" + $FullBakupPrefix + "*"
    $files = get-childitem $ProdBackupFolderPath -filter $FullBakupPrefix -recurse | where {! $_.PSIsContainer} | sort -property LastWriteTime -descending
    $backupfound=0
    #Write-Output $files

    foreach($filename in $files)
    {    
   	    [string] $BackupFilePath = $ProdBackupFolderPath + ''\'' + $filename
        $backupfound=1

    	$txt = ''Most recent Full Backup found is named: '' + $ProdBackupFolderPath + ''\'' + $filename 
	    #Write-Output $txt
    
        break;
    }
    
    if ($backupfound -eq 0 )
    {
	$txt = ''No Full Backup in: '' + $ProdBackupFolderPath
	Write-Output $txt
	return 0
    }

    if ($backupfound -eq 1 )
    {
  	$txt = ''Full Backup found: '' + $ProdBackupFolderPath + ''\'' + $filename 
   	Write-Output $txt
  	$txt = ''Last Write Date Time: '' + $filename.LastWriteTime
  	Write-Output $txt
  	$txt = ''Last Write Day of Week: '' + $filename.LastWriteTime.DayOfWeek
  	Write-Output $txt
    }
	
    if ($BackupFilePath -eq $null)
    {
	$txt = ''No New BackupFile Found in ''+$ProdBackupFolderPath
    	Write-Output  $txt
    	return 0
    }
    
    $cfName = $DestFolder + $ctlfilename + ''.'' + $ctlextension
    $cfContent = $filename.Name     +  "|"          + $filename.Length
	$tp = test-path -path $cfName
    $bkfound =''false''
    
    if ($tp -eq $true)
	{    
        $txt = ''Ctl File Already Found in Destination '' + $DestFolder
    	Write-Output  $txt
    	Write-Output  ''Verifying contents of control file here, if file sizes matches, then skip, else continue...''
    	$ControlFileData =import-Csv $cfName -Delimiter "|" -header "FileName","Filesize" |select FileName,Filesize
        $txt = ''Destination Control File Contents   -> '' + $DestFolder +''->'' +$ControlFileData.Filename +'' -> ''+  $ControlFileData.Filesize
    	Write-Output  $txt
        $txt = ''Source Control File Contents -> '' + $ProdBackupFolderPath+ ''->'' +$filename.Name +'' -> '' + $filename.Length
        Write-Output  $txt
    	if (($ControlFileData.FileName -eq $filename.Name) -and ($ControlFileData.Filesize -eq $filename.Length))
    	{
    		Write-Output ''Last processed backup matches current backup (Database should have been restored already). Proceeding without copying!!!!''
            $bkfound = ''true''
    	}
        else
        {
            Write-Output  ''Control File Contents do not Match. New Backup detected. Proceeding with copy...''
        }
    }

    if ($bkfound -eq ''false'')
    {   
        copy-Item $BackupFilePath $DestBackupFile -Force
        $txt = ''Copied backup file: '' + $DestBackupFile
        Write-Output  $txt
    }

    $RestoreBackupPath = $DestBackupFile
    $txt = ''Backup file to restore: '' + $RestoreBackupPath
    Write-Output  $txt   
        
    #code to create ctl file
    $fso = new-object -comobject scripting.filesystemobject
	$file = $fso.CreateTextFile($cfName,$true)
	$file.close()
	
    Set-Content -Path $cfName -Value $cfContent -force
    }
 
catch {
      $ex = $_.Exception
      Write-Output "$ex.Message"
      Write-Output  $DestBackupFile
      throw $ex
}
', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=34
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Kill all user connections]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Kill all user connections', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @kill varchar(8000) = '''';
select @kill=@kill+''kill ''+convert(varchar(5),spid)+'';''
    from master..sysprocesses 
where dbid=db_id(''STARDB'');
exec (@kill);', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore Full backup]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore Full backup', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [master]
ALTER DATABASE [STARDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [STARDB] FROM  DISK = N''K:\Backups\DBBackup\STARDB_FULL.bak'' WITH  FILE = 1,  MOVE N''STAR'' TO N''F:\SQLFiles\Data\Actuarial\STAR.mdf'',  MOVE N''StarData01'' TO N''F:\SQLFiles\Data\Actuarial\STAR_1.ndf'',  MOVE N''StarData02'' TO N''F:\SQLFiles\Data\Actuarial\STAR_2.ndf'',  MOVE N''StarData03'' TO N''F:\SQLFiles\Data\Actuarial\STAR_3.ndf'',  MOVE N''StarData04'' TO N''F:\SQLFiles\Data\Actuarial\STAR_4.ndf'',  MOVE N''StarINDEX01'' TO N''F:\SQLFiles\Data\Actuarial\STAR_5.ndf'',  MOVE N''StarINDEX02'' TO N''F:\SQLFiles\Data\Actuarial\STAR_6.ndf'',  MOVE N''StarINDEX03'' TO N''F:\SQLFiles\Data\Actuarial\STAR_7.ndf'',  MOVE N''StarINDEX04'' TO N''F:\SQLFiles\Data\Actuarial\STAR_8.ndf'',  MOVE N''STAR_log'' TO N''L:\SQLFiles\Log\Actuarial\STAR_9.ldf'',  NOUNLOAD,  REPLACE, RECOVERY, STATS = 5
ALTER DATABASE [STARDB] SET MULTI_USER
GO', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Clean Production Settings]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Clean Production Settings', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE STARDB
GO

update dbo.tblLocationFTPs
set [Password] = ''''
	, ServerName = ''WCIRBTest''
	, ZipPassword = ''''

update dbo.tblDocumentDeliveryRequests
set FTPPassword = ''''
	, FTPServerName = ''WCIRBTest''
	, FTPZipPassword = '''' 
	
update dbo.tblMIIAlertSubscriptions
set EmailAddress = ''WCRIBTest@Wcirbonline.org''


--Delete from dbo.tblRefSSISConfigurations
Delete from dbo.tblGlobalScapePreferenceDetails
Delete from dbo.tblGlobalScapePreferences

Update dbo.tblDocumentDeliveryRequests set GlobalScapePath = '''' where DeliveryMethodID in (5)
', 
		@database_name=N'STARDB', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Revoke DB Access]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Revoke DB Access', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @UserName VARCHAR(256)
DECLARE csrUser CURSOR  
FOR
    SELECT [name]
    FROM   sys.database_principals
    WHERE  principal_id > 4
           AND is_fixed_role < 1
           AND TYPE <> ''R''
    ORDER BY
           [name]

OPEN csrUser

FETCH NEXT FROM csrUser INTO @UserName

WHILE @@FETCH_STATUS <> -1
BEGIN
    EXEC sp_revokedbaccess @UserName
    PRINT ''Dropped User ''  + @UserName
    FETCH NEXT FROM csrUser INTO @UserName
END

CLOSE csrUser

DEALLOCATE csrUser
', 
		@database_name=N'STARDB', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Reset Permissions]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Reset Permissions', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''SPView'' AND type = ''R'')
CREATE ROLE [SPView]
GO

Grant view definition to [SPView]
GO

EXEC sp_grantdbaccess ''WCIRBOFCA\ActuarialSTARSnapshotUsers''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\ActuarialSTARSnapshotUsers''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\ActuarialSTARSnapshotUsers''

EXEC sp_grantdbaccess ''WCIRBOFCA\StarDBReaders''
EXEC sp_addrolemember N''db_datareader'', N''WCIRBOFCA\StarDBReaders''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\StarDBReaders''

EXEC sp_grantdbaccess ''WCIRBOFCA\Actuarial Services''
EXEC sp_addrolemember N''db_datareader'', N''WCIRBOFCA\Actuarial Services''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\Actuarial Services''

EXEC sp_grantdbaccess ''WCIRBOFCA\DQA Team''
EXEC sp_addrolemember N''db_datareader'', N''WCIRBOFCA\DQA Team''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\DQA Team''

EXEC sp_grantdbaccess ''WCIRBOFCA\IT Engineering''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\IT Engineering''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\IT Engineering''

EXEC sp_grantdbaccess ''WCIRBOFCA\TCSAMSSupport''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\TCSAMSSupport''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\TCSAMSSupport''

EXEC sp_grantdbaccess ''WCIRBOFCA\IT APP Data Services''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\IT APP Data Services''
EXEC sp_addrolemember N''SPView'', N''WCIRBOFCA\IT APP Data Services''

EXEC sp_grantdbaccess ''WCIRBOFCA\IT BSA''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\IT BSA''

EXEC sp_grantdbaccess ''WCIRBOFCA\STARQA''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\STARQA''

EXEC sp_grantdbaccess ''WCIRBOFCA\MDC_Analysts''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\MDC_Analysts''

EXEC sp_grantdbaccess ''WCIRBOFCA\IT EDM''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\IT EDM''

EXEC sp_grantdbaccess ''WCIRBOFCA\IT DBA''
EXEC sp_addrolemember N''udr_Viewer'',  N''WCIRBOFCA\IT DBA''

EXEC sp_grantdbaccess ''WCIRBOFCA\OpsSQLPowerBI''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\OpsSQLPowerBI''

EXEC sp_grantdbaccess ''WCIRBOFCA\svcDSQSBatch''
EXEC sp_addrolemember N''db_datareader'',  N''WCIRBOFCA\svcDSQSBatch''

ALTER LOGIN [WCIRBOFCA\ActuarialSTARSnapshotUsers] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\Actuarial Services] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\DQA Team] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\StarDBReaders] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\IT BSA] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\STARQA] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\MDC_Analysts] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\IT EDM] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\IT Engineering] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\TCSAMSSupport] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\OpsSQLPowerBI] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
ALTER LOGIN [WCIRBOFCA\IT APP Data Services] WITH DEFAULT_DATABASE=[STARDB], DEFAULT_LANGUAGE=[us_english]
GO', 
		@database_name=N'STARDB', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Reset [OpsSQLIgniteAdmin] permission]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Reset [OpsSQLIgniteAdmin] permission', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @DBUser varchar(80)
, @ADUser VARCHAR(80)
, @sql NVARCHAR(4000)
, @RoleName varchar(80)

SET @ADUser = ''OpsSQLIgniteAdmin''
SET @RoleName = ''udr_IgniteAdmin''
SET @DBUser = CASE
					WHEN LEFT(@@servername,3) = ''DEV'' THEN ''DEV\'' + @ADUser
					WHEN LEFT(@@servername,3) = ''TST'' THEN ''STG\'' + @ADUser
					WHEN LEFT(@@servername,3) = ''STG'' THEN ''STG\'' + @ADUser
					ELSE ''WCIRBOFCA\'' + @ADUser
				END

SET @sql = N''USE [STARDB]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'''''' + @RoleName + '''''' AND type = ''''R'''')
BEGIN
	CREATE ROLE ['' + @RoleName + '']
END

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'''''' + @DBUser + '''''')
BEGIN
	CREATE USER ['' + @DBUser + ''] FOR LOGIN ['' + @DBUser + ''] WITH DEFAULT_SCHEMA=db_datareader
END
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'''''' + @RoleName + '''''' AND type = ''''R'''')
BEGIN
	CREATE ROLE ['' + @RoleName + '']
END
GRANT SHOWPLAN TO ['' + @RoleName + '']
EXEC sp_addrolemember ['' + @RoleName + ''], ['' + @DBUser + '']''

PRINT @sql
EXEC sp_executesql @sql
GO', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Shrink and Change Recovery Model]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Shrink and Change Recovery Model', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [master]
GO
ALTER DATABASE [STARDB] SET RECOVERY SIMPLE WITH NO_WAIT
GO
USE [STARDB]
GO
DBCC SHRINKFILE (N''STAR_log'' , 1000)
GO
', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Optimize Indexes]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Optimize Indexes', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d DBAContent -Q "EXECUTE [dbo].[IndexOptimize] @Databases = ''STARDB'', @FragmentationLevel1 = 30, @FragmentationLevel2  = 50, @FragmentationMedium = ''INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'', @FragmentationHigh = ''INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'', @UpdateStatistics = ''All'', @OnlyModifiedStatistics = ''Y'', @LogToTable = ''Y''" -b', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=34
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Statistics]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Statistics', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC  [DBAContent].[dbo].[StatisticsUpdate]
		@DBName = ''STARDB'', -- required database to update
		@All = 0,  -- required flag if to update all statistics or not
		@rmc = 5,	--	required rowmodctr to total rows percentage
		@CutoffRows = 500 --	minimum number of rows in a table

/*
USE [STARDB]
GO

DECLARE @sql nvarchar(4000)

SET @sql = N''EXEC sp_updatestats''
PRINT @sql
EXEC sp_Executesql @sql
*/
GO', 
		@database_name=N'STARDB', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete copied backup file]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete copied backup file', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'$BackupFolderPath = "K:\Backups\DBBackup\STARDB_FULL.bak"
$validpath = test-path -path $BackupFolderPath
if($validpath -eq $False) 
{
       	$txt = ''Can not delete copied STARDB Backup file ''+  $BackupFolderPath + '' because it does not exist!''
	Write-Output  $txt;
}
ELSE
{
	Remove-Item $BackupFolderPath -ErrorAction Stop
	$txt = ''Deleted copied STARDB Backup file '' + $BackupFolderPath + '', used in refreshing ACTUARIAL STARDB snapshot''
	Write-Output  $txt;
}

$BackupFolderPath = "K:\Backups\DBBackup\STARDB_FULL.ctl"
$validpath = test-path -path $BackupFolderPath
if($validpath -eq $False) 
{
       	$txt = ''Can not delete copied STARDB Control file ''+  $BackupFolderPath + '' because it does not exist!''
	Write-Output  $txt;
}
ELSE
{
	Remove-Item $BackupFolderPath -ErrorAction Stop
	$txt = ''Deleted copied STARDB Control file '' + $BackupFolderPath + '', used in refreshing ACTUARIAL STARDB snapshot''
	Write-Output  $txt;
}
', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=34
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [JOB SUCCESS NOTIFICATION]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'JOB SUCCESS NOTIFICATION', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=14, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'ALTER DATABASE [STARDB] SET MULTI_USER
DECLARE @Subject varchar(100),
	@Body varchar(4000),
	@Environment varchar(10),
	@DBName varchar(40),
	@DataAsOf varchar(20),
	@ItemName varchar(120)

-- Get the restore info on STARDB
SET @DBName = ''STARDB''

SELECT TOP 1 @DataAsOf = [bs].[backup_start_date]
FROM msdb..restorehistory AS rs
INNER JOIN msdb..backupset AS bs ON [rs].[backup_set_id] = [bs].[backup_set_id]
INNER JOIN msdb..backupmediafamily AS bmf ON [bs].[media_set_id] = [bmf].[media_set_id] 
WHERE rs.destination_database_name = @DBName 
ORDER BY [rs].[restore_date] DESC		
	
SELECT @Environment = CASE
						WHEN @@servername = ''ACTSNAPDB\Actuarial'' THEN ''PROD''
						WHEN @@servername = ''SFDBCI01\Actuarial'' THEN ''UAT''
						ELSE ''Test''
					END	

SET @ItemName = ''Refresh STARDB Snapshot for Actuarial''
SET @Subject = ''SUCCESS on '' + @@servername + '' ('' + @Environment + ''): '' + @ItemName				
SET @Body 	= ''The STARDB snapshot for Actuarial has been refreshed.'' + CHAR(10) + CHAR(10) + ''Data is as of '' + @DataAsOf + CHAR(10) + CHAR(10) + ''Please contact the IT BSA team if you have questions.''

EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''DBA Mail Profile''
	,@recipients = ''ActSnapDBNotification_dl@wcirb.com;DQA@wcirb.com''
	--,@recipients = ''actsnapdbnotify@wcirb.com;DQA@wcirb.com''
	,@copy_recipients = ''itbsa@wcirb.com; DBANotification@wcirb.com''
	--,@blind_copy_recipients = ''DBANotification@wcirb.com''
	,@body = @Body
	,@subject = @Subject', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [JOB FAILURE NOTIFICATION]    Script Date: 11/17/2018 11:09:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'JOB FAILURE NOTIFICATION', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'ALTER DATABASE [STARDB] SET MULTI_USER
DECLARE @Subject varchar(100),
	@Body varchar(4000),
	@Environment varchar(10),
	@DBName varchar(40),
	@DataAsOf varchar(20),
	@ItemName varchar(120)

-- Get the restore info on STARDB
SET @DBName = ''STARDB''

SELECT TOP 1 @DataAsOf = [bs].[backup_start_date]
FROM msdb..restorehistory AS rs
INNER JOIN msdb..backupset AS bs ON [rs].[backup_set_id] = [bs].[backup_set_id]
INNER JOIN msdb..backupmediafamily AS bmf ON [bs].[media_set_id] = [bmf].[media_set_id] 
WHERE rs.destination_database_name = @DBName 
ORDER BY [rs].[restore_date] DESC

SELECT @Environment = CASE
						WHEN @@servername = ''ACTSNAPDB\Actuarial'' THEN ''PROD''
						WHEN @@servername = ''SFDBCI01\Actuarial'' THEN ''UAT''
						ELSE ''Test''
					END	

SET @ItemName = ''Refresh STARDB Snapshot for Actuarial''
SET @Subject = ''FAILURE on '' + @@servername + '' ('' + @Environment + ''): '' + @ItemName				
SELECT @Body 	= ''The STARDB snapshot for Actuarial has not been refreshed today.'' + CHAR(10) + CHAR(10) +  ''Data is still as of '' + @DataAsOf + CHAR(10) + CHAR(10) + ''IT DBA is looking into the matter and will update you in a couple of hours.''

IF DATENAME(weekday,getdate()) NOT IN (''Sunday'', ''Monday'')
BEGIN
	EXEC msdb.dbo.sp_send_dbmail
	@profile_name = ''DBA Mail Profile''
	,@recipients = ''actsnapdbnotify@wcirb.com;DQA@wcirb.com''
	,@copy_recipients = ''itbsa@wcirb.com; DBANotification@wcirb.com''
	,@blind_copy_recipients = ''DBAPage@wcirb.com''
	,@body = @Body
	,@subject = @Subject
END', 
		@database_name=N'master', 
		@output_file_name=N'L:\SQLFiles\Agent\Refresh STARDB Snapshot for Actuarial.txt', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Refresh STARDB Snapshot for Actuarial - Weekday', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=124, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20130507, 
		@active_end_date=99991231, 
		@active_start_time=63000, 
		@active_end_time=235959, 
		@schedule_uid=N'e04d0816-5091-4a93-a4e6-c0d94200f05d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

