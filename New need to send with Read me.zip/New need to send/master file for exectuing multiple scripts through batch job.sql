/*
MESSAGE TO THE DBA WHO IS RUNNING THIS: 
SET SQLCMD Mode ON and set the following path variable to the folder where you have saved the scripts:
*/

:setvar path "\\GBLEE5-FP3\Joe.Vorlicky$\tfs_sme\Database Project\ADSVM7\JIRA Tasks\BOB-3213 LQS Show SalesTeamName of FirstQuote\ADSSQL (BOB-3213)\implementation"

/*

CONCERNS JIRA TICKETS:
BOB-3213

*/


-- IMPLEMENTATION MASTER FILE FOR ADSSQL
-- UNIT TESTED ON GBLEE5-DEVSQL\GBLEE5SMEDEV


--Pre-release - e.g. data backups
:r $(path)\CREATE_BACKUP_TABLES.sql
print 'Script CREATE_BACKUP_TABLES.sql complete.'

--Tables
:r $(path)\insight_LeadQuoteSaleTable.sql
print 'Script insight_LeadQuoteSaleTable.sql complete.'

--Procedures
:r $(path)\sp_InsightOverSource_LeadQuoteSaleTable.sql
print 'Script sp_InsightOverSource_LeadQuoteSaleTable.sql complete.'

-- one-time run to reload the table with data from new object definitions:
:r $(path)\RELOAD_HISTORIC_DATA.sql
print 'Script RELOAD_HISTORIC_DATA.sql complete.'

print 'Release complete. Thank you.'