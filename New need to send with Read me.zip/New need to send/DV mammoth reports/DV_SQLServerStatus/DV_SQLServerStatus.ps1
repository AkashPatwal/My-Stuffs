
$freeSpaceFileName = "C:\DV\DV_SQLServerStatus\DV_SQLServerStatus.htm" 
$serverlist = "C:\DV\DV_SQLServerStatus\serverlist.txt" 

New-Item -ItemType file $freeSpaceFileName -Force 

# Function to write the HTML Header to the file 
Function writeHtmlHeader 
{ 
param($fileName) 
$date = ( get-date ).ToString('yyyy/MM/dd') 
Add-Content $fileName "<html>" 
Add-Content $fileName "<head>" 
Add-Content $fileName "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>" 
Add-Content $fileName '<title>SQLSERVER Monitoring Report</title>' 
add-content $fileName '<STYLE TYPE="text/css">' 
add-content $fileName  "<!--" 
add-content $fileName  "td {" 
add-content $fileName  "font-family: Verdana;" 
add-content $fileName  "font-size: 11px;" 
add-content $fileName  "border-top: 1px solid #999999;" 
add-content $fileName  "border-right: 1px solid #999999;" 
add-content $fileName  "border-bottom: 1px solid #999999;" 
add-content $fileName  "border-left: 1px solid #999999;" 
add-content $fileName  "padding-top: 0px;" 
add-content $fileName  "padding-right: 0px;" 
add-content $fileName  "padding-bottom: 0px;" 
add-content $fileName  "padding-left: 0px;" 
add-content $fileName  "}" 
add-content $fileName  "body {" 
add-content $fileName  "margin-left: 5px;" 
add-content $fileName  "margin-top: 5px;" 
add-content $fileName  "margin-right: 0px;" 
add-content $fileName  "margin-bottom: 10px;" 
add-content $fileName  "" 
add-content $fileName  "table {" 
add-content $fileName  "border: thin solid #000000;" 
add-content $fileName  "}" 
add-content $fileName  "-->" 
add-content $fileName  "</style>" 
Add-Content $fileName "</head>" 
Add-Content $fileName "<body>" 
 
add-content $fileName  "<table width='100%'>" 
add-content $fileName  "<tr bgcolor='#CCCCCC'>" 
add-content $fileName  "<td colspan='7' height='25' align='center'>" 
add-content $fileName  "<font face='tahoma' color='#003399' size='4'><strong>SQL Server Status Monitoring Report - $date</strong></font>" 
add-content $fileName  "</td>" 
add-content $fileName  "</tr>" 
add-content $fileName  "</table>" 
 
} 
 
# Function to write the HTML Header to the file 
Function writeTableHeader 
{ 
param($fileName) 
 
Add-Content $fileName "<tr bgcolor=#CCCCCC>" 
Add-Content $fileName "<td width='20%' align='center'>Service Name</td>" 
Add-Content $fileName "<td width='20%' align='center'>Status </td>" 
Add-Content $fileName "<td width='20%' align='center'>startup_name</td>" 
Add-Content $fileName "<td width='20%' align='center'>startmode</td>" 
Add-Content $fileName "<td width='20%' align='center'>Start_Date</td>"
Add-Content $fileName "</tr>" 
} 
 
Function writeHtmlFooter 
{ 
param($fileName) 
 
Add-Content $fileName "</body>" 
Add-Content $fileName "</html>" 
} 
 
Function writeDiskInfo 
{ 
param($fileName,$devId,$volName,$frSpace,$totSpace,$Days) 
 
if ($freePercent -gt $warning) 
 { 
 Add-Content $fileName "<tr>" 
 Add-Content $fileName "<td>$devid</td>" 
 Add-Content $fileName "<td>$volName</td>" 
  Add-Content $fileName "<td>$frSpace</td>" 
 Add-Content $fileName "<td>$totSpace</td>" 
 Add-Content $fileName "<td>$Days</td>"
 Add-Content $fileName "</tr>" 
 } 

 
 elseif ($volName -ne "Running") 
 { 
 Add-Content $fileName "<tr>" 
 Add-Content $fileName "<td>$devid</td>" 
 Add-Content $fileName "<td>$volName</td>" 
 Add-Content $fileName "<td>$frSpace</td>" 
 Add-Content $fileName "<td>$totSpace</td>"
 Add-Content $fileName "<td bgcolor='#FF0000' fgcolor='#FFF' align=center>$Days</td>" 
 #<td bgcolor='#FF0000' align=center> 
 Add-Content $fileName "</tr>" 
 } 
 else 
 { 
 Add-Content $fileName "<tr>" 
 Add-Content $fileName "<td>$devid</td>" 
 Add-Content $fileName "<td>$volName</td>" 
 Add-Content $fileName "<td>$frSpace</td>" 
 Add-Content $fileName "<td>$totSpace</td>" 
 Add-Content $fileName "<td>$Days</td>"
 # #FBB917 
 Add-Content $fileName "</tr>" 
 } 
} 
 
Function sendEmail 
{ param($from,$to,$subject,$smtphost,$htmlFileName) 
$body = Get-Content $htmlFileName 
$smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
$msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
$msg.isBodyhtml = $true 
$smtp.send($msg) 
 
} 
 
writeHtmlHeader $freeSpaceFileName 
foreach ($server in Get-Content $serverlist) 
{ 
 Add-Content $freeSpaceFileName "<table width='100%'><tbody>" 
 Add-Content $freeSpaceFileName "<tr bgcolor='#CCCCCC'>" 
 Add-Content $freeSpaceFileName "<td width='100%' align='center' colSpan=6><font face='tahoma' color='#003399' size='2'><strong> $server </strong></font></td>" 
 Add-Content $freeSpaceFileName "</tr>" 

 writeTableHeader $freeSpaceFileName 
$StartTime= @{n='StartTime';e={$_.ConvertToDateTime($_.CreationDate)}}
$delta =gwmi win32_process -ComputerName $server -filter "Name='sqlservr.exe'" | select $StartTime 


$deltastopped= 'Please start the SQL Server Services' 
 
$dp = Get-WmiObject -Class win32_service  -ComputerName $server -Property startmode, startname, name,state | where {($_.name -like "MSSQL$*") -or ($_.name -like "MSSQLServer")  -and ($_.name -notlike "*MICROSOFT*") } | select name, state, startname, startmode 
 foreach ($item in $dp) 
 { 

if ($item.state -ne "Running")
{

 Write-Host  $item.name  $item.state $item.startname $item.startmode $delta[0].timewritten
 writeDiskInfo $freeSpaceFileName $item.name $item.state $item.startname $item.startmode $deltastopped 
 }
else 
{
 Write-Host  $item.name  $item.state $item.startname $item.startmode $delta[0].StartTime
 writeDiskInfo $freeSpaceFileName $item.name $item.state $item.startname $item.startmode $delta[0].StartTime 
}


 } Add-Content $freeSpaceFileName "</table>" 
} 
 


writeHtmlFooter $freeSpaceFileName 
$date = ( get-date ).ToString('yyyy/MM/dd') 

foreach ($Mail in Get-Content $freeSpaceFileName ) 
{
if($Mail.Contains("Stop")) 
{ 
 
sendEmail sysdba@mammoth-mtn.com "SQL@datavail.com,Shashidhar.mankala@datavail.com" "Mammoth :: SQL Server services Monitoring Report - $Date"  "msa-exchange1.mmsa.local" $freeSpaceFileName 

} 
}