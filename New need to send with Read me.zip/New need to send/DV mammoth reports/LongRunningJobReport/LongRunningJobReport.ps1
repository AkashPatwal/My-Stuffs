

#Try
#{
    clear; # clear the screen
    $i=0
    $date = ( get-date ).ToString('yyyy/MM/dd') 

    Function sendEmail 
    { param($from,$to,$subject,$smtphost,$htmlFileName) 
    $body = Get-Content $htmlFileName 
    $smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
    $msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
    $msg.isBodyhtml = $true 
    $smtp.send($msg) 
    } 

    $hostname = get-content env:computername
    $rpath = split-path -parent $MyInvocation.MyCommand.Definition
    Write-host $rpath
    $path = $rpath.split(":")
    $dir = $path[0]
    $file = $path[1]
    $mailctr = 0
    
    
    #Add/Import PSSnapin/Module required for SQL Server
    #--------------------------------------------------
    #Checking version 
    $versionPS = $host.Version
    write-host $versionPS
    if ($versionPS -ge '1.0')
    {
        Import-Module SqlPs
        write-host "Module imported"
        
        $cpath = "$dir``$"
        $globalPath = "\\$hostname\$cpath$file"
    }
    else
    {
        
        if((Get-PSSnapin | where-object {$_.Name -eq "SqlServerCmdletSnapin100"}) -eq $null) 
        {Add-PsSnapin SqlServerCmdletSnapin100}

        if((Get-PSSnapin | where-object {$_.Name -eq "SqlServerProviderSnapin100"}) -eq $null) 
        {Add-PSSnapin SqlServerProviderSnapin100}
        #---Adding PSSnapin end----------------
        write-host "Snappin added"
        
        $globalPath = "\\$hostname\$rpath" -replace ":", "$"
    }
    
    
    [String]$clientName=""

    Write-host "##---------------------------------------------------##" -fore BLACK -background WHITE
    Write-host " " -fore BLACK -background WHITE
    Write-host "Root Path:"$path  -fore BLACK -background WHITE
    Write-host "Hostname:"$hostname  -fore BLACK -background WHITE
    Write-host "Global Path:"$globalPath  -fore BLACK -background WHITE
    Write-host " "  -fore BLACK -background WHITE


    # write code for getting a server list
    #$getServerList = get-Content "$globalPath\Server-List.txt".ToString()
    $getServerList = get-Content "$rPath\Server-List.txt".ToString()
    if ($getServerList -eq $null)
        {
            Write-host "Not able to read the Server-List.txt file"
            EXIT
            #$getServerList = $hostname
        }

    if((test-path "$rPath\LongRunningJobReport.HTML" -pathtype Leaf))
	    {Remove-Item "$rPath\LongRunningJobReport.HTML"}
    
   
    
    $myData = @()
    $svrProp = @()
    $smtpAdd = @()
    $recp = @()  
    $frm = @()
    $params = @()  
    
    foreach ($item in $getServerList)
    {
        if (!$item)
        {$item = "--"}
    
        if (($item.Substring(0,2) -ne "--"))
	    {
    	    if ($item.Substring(0,1) -eq "@")
            {
			    $params = $item.split("=")
                if ($params[0] -eq "@SMTP")
                {
        		    $mailex = $params[1]
        	    }
        	    if ($params[0] -eq "@RECT")
    		    {
    			    $recpt = $params[1]
    		    }
			    if ($params[0] -eq "@FROM")
    		    {
    			    $frm = $params[1]
    		    }
            }
            else
            {
                if ($item.Contains("("))
                {
                    $svrProp = $item.split("(")
                    Write-host $svrProp[0]
                    Write-host $svrProp[1]
                
                    $svrDet = $svrProp[0]
                    $excList = $svrProp[1].split(")")
                    $excJOBlist = $excList[0]
                    $excJOBlist = "'$excJOBlist'"
                
                    Write-host "-----------"
                    Write-host $svrDet
                    Write-host $excJOBlist               
                
                    $svrConn = $svrDet.split(",")
                    $getServer = $svrConn[0]
                    $durr = $svrConn[1]
                }
                else
                {
                    $svrConn = $item.split(",")
                    $getServer = $svrConn[0]
                    $durr = $svrConn[1]
                    $excJOBlist = "''"
                }               

                #EXIT
                if (!$getServer)
                {
                    Write-host "Cannot proceed without Server name"
                    EXIT
                }
                if (!$durr)
                {
                    $durr = 0
                }
                if (!$excJOBlist)
                {
                    $excJOBlist = ""
                }
                $vsql = "durr=$durr", "excJOBlist=$excJOBlist"
            
                Write-host "Server: $getServer Thresholds for, Duration: $durr excJOBlist: $excJOBlist" -fore BLACK -background WHITE
            
        	    $myData = invoke-sqlcmd -InputFile "$rPath\Report.sql" -serverinstance $getServer -database tempdb -querytimeout ([int]::MaxValue) -MaxCharLength 1000000 -Variable $vsql;
        	    #$mydata | out-file "$globalPath\LongRunningJobReport.HTML" -Append -Width 1000000;
                $col = ""
                $col = $mydata.Col
                #$col = $col.Substring(6, ($col.length-6))
                
                $f = ""
                $f = select-string -inputobject $col -pattern "<html>" 
                WRITE-HOST $f
                if (!(!$f))
                {
                    $col | out-file "$rPath\LongRunningJobReport.HTML" -Append -Width 1000000;
                    $mailctr += 1
                }
                
        	    $i += 1;
            }
        }
    }
    
    if ($mailctr -gt 0)
    {
        $Gtdate = Get-Date
        $yy = $Gtdate.Year
        $Fnote = "<p align=""center"" class=""footnote"">
        <font face=""Segoe UI"" size=""1"">
        &copy; 2008&mdash;$yy datAvail Corporation.<br/>
        This is intellectual property of datAvail Corporation;.<br/>
        Any use or modification without prior notification and permission is illegal and will be prosecuted.
        </font>
        </p>"
        $Fnote | out-file "$rPath\LongRunningJobReport.HTML" -Append -Width 1000000;

        Write-host "Backup report executed for $i server(s)." -fore BLACK -background WHITE

        #Remove-PSSnapin SqlServerCmdletSnapin100;

        if (!$frm -or !$mailex -or !$recpt)
        {
            Write-host "Reports cannot be emailed as either SMTP address or receipent address is not given..." -fore BLACK -background WHITE
            exit
        }
        sendEmail $frm $recpt "Mammoth :: Long Running Job Report - $Date" $mailex "$rPath\LongRunningJobReport.HTML"
        EXIT
    }
#}
#Catch
#{
    #$ErrorMessage = $_.Exception.Message
    #$ErrorMessage | out-file -Append -filepath "$globalPath\failed.log"
#}