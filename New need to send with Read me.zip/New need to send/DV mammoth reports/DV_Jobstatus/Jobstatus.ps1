
if ( (Get-PSSnapin -Name SqlServerProviderSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerProviderSnapin100
}


if ( (Get-PSSnapin -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerCmdletSnapin100
}





# First lets create a text file, where we will later save the job info
$CurrentTime=get-date
$Jobstatus = "C:\dv\DV_Jobstatus\JobStatus.htm"
$serverlist = (Get-Location).Path +"\serverlist.txt"
$outfile =(Get-Location).Path +"\out.txt"
New-Item -ItemType file $Jobstatus -Force
New-Item -ItemType file $outfile -Force


Function writeHtmlHeader
{
param($Jobstatus)
$date = ( get-date ).ToString('MM/dd/yyyy')
Add-Content $Jobstatus "<html>"
Add-Content $Jobstatus "<head>"
Add-Content $Jobstatus "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>"
Add-Content $Jobstatus '<title>JobStatus Report</title>'
add-content $Jobstatus '<STYLE TYPE="text/css">'
add-content $Jobstatus  "<!--"
add-content $Jobstatus  "td {"
add-content $Jobstatus  "font-family: Tahoma;"
add-content $Jobstatus  "font-size: 11px;"
add-content $Jobstatus  "border-top: 1px solid #999999;"
add-content $Jobstatus  "border-right: 1px solid #999999;"
add-content $Jobstatus  "border-bottom: 1px solid #999999;"
add-content $Jobstatus  "border-left: 1px solid #999999;"
add-content $Jobstatus  "padding-top: 0px;"
add-content $Jobstatus  "padding-right: 0px;"
add-content $Jobstatus  "padding-bottom: 0px;"
add-content $Jobstatus  "padding-left: 0px;"
add-content $Jobstatus  "}"
add-content $Jobstatus  "p  { "
add-content $Jobstatus  "margin-left: 20px;"
add-content $Jobstatus  "font-size: 12px; "
add-content $Jobstatus      "}"
add-content $Jobstatus  "body {"
add-content $Jobstatus  "margin-left: 5px;"
add-content $Jobstatus  "margin-top: 5px;"
add-content $Jobstatus  "margin-right: 0px;"
add-content $Jobstatus  "margin-bottom: 10px;"
add-content $Jobstatus  ""
add-content $Jobstatus  "table {"
add-content $Jobstatus  "border: thin solid #000000;"
add-content $Jobstatus  "}"
add-content $Jobstatus  "-->"
add-content $Jobstatus  "</style>"
Add-Content $Jobstatus "</head>"
Add-Content $Jobstatus "<body>"

add-content $Jobstatus  "<table width='100%'>"
add-content $Jobstatus  "<tr bgcolor='#CCCCCC'>"
add-content $Jobstatus  "<td colspan='7' height='25' align='center'>"
add-content $Jobstatus  "<font face='tahoma' color='#003399' size='4'><strong>Job Status - $date</strong></font>"
add-content $Jobstatus  "</td>"
add-content $Jobstatus  "</tr>"
add-content $Jobstatus  "</table>"

}

# Function to write the HTML Header to the file
Function writeTableHeader
{
param($Jobstatus)

Add-Content $Jobstatus "<tr bgcolor=#CCCCCC>"
Add-Content $Jobstatus "<td width='40%' align='center'>JobName</td>"
Add-Content $Jobstatus "<td width='20%' align='center'>Last_run_status</td>"
Add-Content $Jobstatus "<td width='20%' align='center'>Last_run_date</td>"
Add-Content $Jobstatus "<td width='20%' align='center'>Last_run_time</td>"
Add-Content $Jobstatus "</tr>"
}

Function writeHtmlFooter
{
param($Jobstatus)
Add-Content $Jobstatus "</table>"
Add-Content $Jobstatus "</body>"
Add-Content $Jobstatus "<hr noshade size=3 width=""100%"">"
Add-Content $Jobstatus "<div id =""footer"">"
Add-Content $Jobstatus "<P align = ""Right""> Execution Time: $CurrentTime  ; Developed By DV </P></div>"
Add-Content $Jobstatus "</html>"
}

Function writeJobInfo
{
param($Jobstatusf,$JobName,$last_run_status,$last_run_date,$last_run_time)

if ($last_run_status -eq "Failed")
 {
 Add-Content $Jobstatusf "<tr>"
 Add-Content $Jobstatusf "<td Width=""40%"" style=""background-color:red "" >$JobName</td>" 
 Add-Content $Jobstatusf "<td Width=""20%"" style=""background-color:red "" align=center>$last_run_status</td>"
 Add-Content $Jobstatusf "<td Width=""20%"" style=""background-color:red "" align=center>$last_run_date</td>" 
 Add-Content $Jobstatusf "<td Width=""20%"" style=""background-color:red ""  align=center>$last_run_time</td>"
 Add-Content $Jobstatusf "</tr>" 
}

elseif ($last_run_status -eq "SUCCESS")
{
 Add-Content $Jobstatusf "<tr>"
 Add-Content $Jobstatusf "<td Width=""40%"" >$JobName</td>" 
 Add-Content $Jobstatusf "<td Width=""20%"" align=center>$last_run_status</td>"
 Add-Content $Jobstatusf "<td Width=""20%"" align=center>$last_run_date</td>" 
 Add-Content $Jobstatusf "<td Width=""20%"" align=center>$last_run_time</td>"
 Add-Content $Jobstatusf "</tr>" 
}


else 
{
 Add-Content $Jobstatusf "<tr>"
 Add-Content $Jobstatusf "<td Width=""40%""  style=""background-color:#F8E95F"" >$JobName</td>" 
 Add-Content $Jobstatusf "<td Width=""20%""  style=""background-color:#F8E95F""  align=center>$last_run_status</td>"
 Add-Content $Jobstatusf "<td Width=""20%""  style=""background-color:#F8E95F"" align=center>$last_run_date</td>" 
 Add-Content $Jobstatusf "<td Width=""20%""  style=""background-color:#F8E95F"" align=center>$last_run_time</td>"
 Add-Content $Jobstatusf "</tr>" 
}

}

writeHtmlHeader $Jobstatus

foreach ($SQLServer in Get-Content $serverlist)
{
 Add-Content $Jobstatus "<table width='100%'><tbody>"
 Add-Content $Jobstatus "<tr bgcolor='#CCCCCC'>"
 Add-Content $Jobstatus "<td width='100%' align='center' colSpan=6><font face='tahoma' color='#003399' size='2'><strong> $SQLServer </strong></font></td>"
 Add-Content $Jobstatus "</tr>"
 

 writeTableHeader $Jobstatus
 
 Write-Host "**********************************************************************************************************"
   Write-Host " ***********************************Job Analysis for $SQLServer started********************************"
   Write-Host "**********************************************************************************************************" 

 $job = invoke-sqlcmd �ServerInstance $SQLServer -Database "dbainfo" -Query "exec usp_dailyjobreport" -ConnectionTimeout 600 -QueryTimeout 300

 foreach ($item in $job)
 
  
  {
  
  #Write-Host  $item."Job Name"  $item.last_run_status $item.last_run_date  $item.last_run_time
  writeJobInfo  $Jobstatus $item."Job Name"  $item.last_run_status $item.last_run_date  $item.last_run_time

  }Add-Content $Jobstatus "</table>" 

trap [Exception]
			{ 
				  Echo "Processing exception"
				  $ExceptionText = $_.Exception.Message -replace "'", "" 
				  $ExceptionMessage = $SQLServer +"         ,                 "+ $_.Exception.GetType().FullName + "        ,        " + $ExceptionText  | out-file $outfile -append
		

Write-Host "Job Analysis Failed for $SQLServer"
				  continue;   
			}



$job=" "

Write-Host "Job Analysis completed for $SQLServer"

}

Function sendEmail 
{ param($from,$to,$subject,$smtphost,$htmlFileName) 
$body = Get-Content $htmlFileName 
$smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
$msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
$msg.isBodyhtml = $true 
$smtp.send($msg) 
 
} 

writeHtmlFooter $Jobstatus
$date = ( get-date ).ToString('yyyy/MM/dd')
sendEmail sysdba@mammoth-mtn.com "shashidhar.mankala@datavail.com" "Mammoth :: Job Status Report - $Date"  "msa-exchange1.mmsa.local" $Jobstatus
