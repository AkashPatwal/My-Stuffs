USE [msdb]
GO

/****** Object:  Job [DV_SQL_Login_Audit]    Script Date: 11/27/2018 6:34:02 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:34:02 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_SQL_Login_Audit', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Login_audit]    Script Date: 11/27/2018 6:34:02 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Login_audit', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(''tempdb..#audittemp'') IS NOT NULL DROP TABLE #audittemp
create table #audittemp(server_principal_name varchar(100),event_time varchar(25),address varchar(100));

IF OBJECT_ID(''tempdb..#tmp'') IS NOT NULL DROP TABLE #tmp
CREATE TABLE #tmp (data NVARCHAR(500))

Declare @Dir VARCHAR(256), @CMD VARCHAR(256)
SET @Dir = ''f:\MSSQL10_50.SNSERVER01\MSSQL\Log\''
SET @CMD = ''DIR "''+@DIR+''" /A /S''

INSERT #tmp EXEC master..xp_cmdshell @cmd
DELETE FROM #tmp WHERE data IS NULL
DELETE FROM #tmp WHERE data NOT LIKE ''%.sqlaudit''

select RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) AS [file_name],GETDATE()
 from #tmp where REPLACE(SUBSTRING(data,22,17),'','','''') > 0 and RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) not in (select filename from Login_audit_fileprocessed)
 
 IF (@@ROWCOUNT > 0)
    BEGIN

Declare @filename varchar(300)
Declare @sql varchar(max)
 declare display CURSOR for  
 select RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) AS [file_name]
 from #tmp where REPLACE(SUBSTRING(data,22,17),'','','''') > 0 and RIGHT(RTRIM([data]),LEN(RTRIM([data]))-39) not in (select filename from Login_audit_fileprocessed)
 
		open display 
		fetch next from display into @filename
			while (@@fetch_status = 0)
			BEGIN 
							
				set @sql = 
				''WITH XMLNAMESPACES(DEFAULT ''+CHAR(39)+''http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data''+CHAR(39)+'')
				INSERT INTO #audittemp
				SELECT	server_principal_name,
				CONVERT(VARCHAR(16),event_time),
				CAST(additional_information AS xml).value(''+CHAR(39)+''(action_info/address/text())[1]''+CHAR(39)+'', ''+CHAR(39)+''varchar(255)''+CHAR(39)+'') as address
				FROM	sys.fn_get_audit_file (''+CHAR(39)+@Dir +''\''+@filename+CHAR(39)+'',default,default)''
				
				exec (@sql)

				Insert into login_audit 
				select distinct * from #audittemp where  
				address not in (select distinct IPAddress from [MANAGEMENT].[dbo].[AllowedClientIPs]);					
				
				Insert into Login_audit_fileprocessed values (@filename,GETDATE())
								
				truncate table #audittemp
				fetch next from display into @filename
			END
		CLOSE display
		deallocate display

END
', 
		@database_name=N'MANAGEMENT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily every 30mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=30, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150828, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b8d472fb-e3e6-4954-9294-8c0e77430713'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

