USE [MANAGEMENT]
GO

/****** Object:  Table [dbo].[login_audit]    Script Date: 11/27/2018 6:35:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[login_audit](
	[server_principal_name] [varchar](100) NULL,
	[event_time] [varchar](25) NULL,
	[address] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[Login_audit_fileprocessed]    Script Date: 11/27/2018 6:35:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Login_audit_fileprocessed](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Filename] [nvarchar](500) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]

GO

