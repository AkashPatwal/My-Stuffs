#Author: Anup Gopinathan | Datavail

clear; # clear the screen
$i=0
$date = ( get-date ).ToString('yyyy/MM/dd') 

Function sendEmail 
{ 
    param($from,$to,$subject,$smtphost,$htmlFileName) 
    $body = Get-Content $htmlFileName 
    $smtp= New-Object System.Net.Mail.SmtpClient $smtphost 
    $msg = New-Object System.Net.Mail.MailMessage $from, $to, $subject, $body 
    $msg.isBodyhtml = $true 
    $smtp.send($msg) 
} 

$hostname = get-content env:computername
$rpath = split-path -parent $MyInvocation.MyCommand.Definition
Write-host $rpath
$path = $rpath.split(":")
$dir = $path[0]
$file = $path[1]
    
#Add/Import PSSnapin/Module required for SQL Server
#--------------------------------------------------
#Checking version 
$versionPS = $host.Version
write-host $versionPS
if ($versionPS -ge '4.0')
{
    Import-Module SqlPs
    write-host "Module imported"
        
    $cpath = "$dir``$"
    $globalPath = "\\$hostname\$cpath$file"
}
else
{
        
    if((Get-PSSnapin | where-object {$_.Name -eq "SqlServerCmdletSnapin100"}) -eq $null) 
    {Add-PsSnapin SqlServerCmdletSnapin100}

    if((Get-PSSnapin | where-object {$_.Name -eq "SqlServerProviderSnapin100"}) -eq $null) 
    {Add-PSSnapin SqlServerProviderSnapin100}
    #---Adding PSSnapin end----------------
    write-host "Snappin added"
        
    $globalPath = "\\$hostname\$rpath" -replace ":", "$"
}
    
    # write code for getting a server list
#$getServerList = get-Content "$globalPath\Server-List.txt".ToString()
$getServerList = get-Content "$rPath\Server-List.txt".ToString()
if ($getServerList -eq $null)
    {
        Write-host "Not able to read the Server-List.txt file"
        EXIT
        #$getServerList = $hostname
    }

if((test-path "$rPath\LongRunningJobReport.HTML" -pathtype Leaf))
	{Remove-Item "$rPath\LongRunningJobReport.HTML"}
    
[String]$clientName=""

Write-host "##---------------------------------------------------##" -fore BLACK -background WHITE
Write-host " " -fore BLACK -background WHITE
Write-host "Root Path:"$path  -fore BLACK -background WHITE
Write-host "Hostname:"$hostname  -fore BLACK -background WHITE
Write-host "Global Path:"$globalPath  -fore BLACK -background WHITE
Write-host " "  -fore BLACK -background WHITE

#Inital basic html page tags
$htmlBody = "<html>"
$htmlBody = $htmlBody + "<h2><font face=""Calibri"" size=""4"">ACTIVE SERVER SESSIONS REPORT for $date</Font></h2>"
$htmlBody = $htmlBody + "<BODY>"

$myData = @()
$svrProp = @()
$smtpAdd = @()
$recp = @()  
$frm = @()
$params = @()  
    
foreach ($item in $getServerList)
{
    if (!$item)
    {$item = "--"}
    
    if (($item.Substring(0,2) -ne "--"))
	{
    	if ($item.Substring(0,1) -eq "@")
        {
			$params = $item.split("=")
            if ($params[0] -eq "@SMTP")
            {
        		$mailex = $params[1]
        	}
        	if ($params[0] -eq "@RECT")
    		{
    			$recpt = $params[1]
    		}
			if ($params[0] -eq "@FROM")
    		{
    			$frm = $params[1]
    		}
        }
        else
        {
            if ($item.Contains("("))
            {
                $svrProp = $item.split("(")
                Write-host $svrProp[0]
                Write-host $svrProp[1]
                
                $svrDet = $svrProp[0]
                $excList = $svrProp[1].split(")")
                $excJOBlist = $excList[0]
                $excJOBlist = "'$excJOBlist'"
                
                Write-host "-----------"
                Write-host $svrDet
                Write-host $excJOBlist               
                
                $svrConn = $svrDet.split(",")
                $getServer = $svrConn[0]
                $durr = $svrConn[1]
            }
            else
            {
                $svrConn = $item.split(",")
                $getServer = $svrConn[0]
                $durr = $svrConn[1]
                $excJOBlist = "''"
            }               

            #EXIT
            if (!$getServer)
            {
                Write-host "Cannot proceed without Server name"
                EXIT
            }
            if (!$durr)
            {
                $durr = 0
            }
            if (!$excJOBlist)
            {
                $excJOBlist = ""
            }
            $vsql = "durr=$durr", "excJOBlist=$excJOBlist"
            
            $ServerName = $getServer

            #Creating a table
            $htmlBody = $htmlBody + "<br>"
            $htmlBody = $htmlBody + "<TABLE BORDER=""2"" width=""100%"">"
            $htmlBody = $htmlBody + "<TR bgcolor=""#b8944d""><TD align=""center"" colspan=""6""><font face=""Calibri"" size=""2""><b>Server: $ServerName</b><font face=""Calibri"" size=""2""></TD></TR>"

            #Defining table header
            $htmlBody = $htmlBody + "<TR>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""30%""><font face=""Calibri"" size=""2""> Session Name </Font></TH>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""30%""><font face=""Calibri"" size=""2""> User Name </Font></TH>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""10%""><font face=""Calibri"" size=""2""> ID </Font></TH>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""10%""><font face=""Calibri"" size=""2""> State </Font></TH>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""10%""><font face=""Calibri"" size=""2""> IDLE TIME </Font></TH>"
            $htmlBody = $htmlBody + "<TH bgcolor=""#B8B8B8"" width=""10%""><font face=""Calibri"" size=""2""> Login Time </Font></TH>"
            $htmlBody = $htmlBody + "</TR>"

            Write-Host �Querying $ServerName�
            #$queryResults = (quser /server:$ServerName | foreach { (($_.trim() -replace �\s+�,�,�))})
            $queryResults = (qwinsta /server:$ServerName | foreach { (($_.trim() -replace �\s+�,�,�))} | ConvertFrom-Csv)

            #listing table data
            ForEach ($queryResult in $queryResults) 
            {

                $sessionType = $queryResult.SESSIONNAME
                $RDPUser = $queryResult.USERNAME
                $id = $queryResult.ID
                $state = $queryResult.State
                $Type = $queryResult.Type
                $Device = $queryResult.Device

                if (!$sessionType)
                {
                    $sessionType = "-"
                }
                if (!$RDPUser)
                {
                    $RDPUser = "-"
                }
                if (!$id)
                {
                    $id = "-"
                }
                if (!$state)
                {
                    $state = "-"
                }
                if (!$Type)
                {
                    $Type = "-"
                }
                if (!$Device)
                {
                    $Device = "-"
                }

                If (($RDPUser -match �[a-z]�) -and ($RDPUser -ne $NULL)) 
                {
                    $htmlBody = $htmlBody + "<TR>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$sessionType</Font></TD>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$RDPUser</Font></TD>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$ID</Font></TD>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$State</Font></TD>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$Type</Font></TD>"
                    $htmlBody = $htmlBody + "<TD><font face=""Calibri"" size=""2"">$Device</Font></TD>"
                    $htmlBody = $htmlBody + "</TR>"
                }
                
            }
        $htmlBody = $htmlBody + "</Table>"
        $i += 1;
        }
    }
}


$htmlBody = $htmlBody + "</Body>"
$htmlBody = $htmlBody + "</html>"
#write-host $htmlBody
$htmlBody | out-file "$rPath\LongRunningJobReport.HTML" -Append -Width 1000000;

#FootNote
$Gtdate = Get-Date
$yy = $Gtdate.Year
$Fnote = "<p align=""center"" class=""footnote"">
<font face=""Segoe UI"" size=""1"">
&copy; 2008&mdash;$yy datAvail Corporation.<br/>
This is intellectual property of datAvail Corporation;.<br/>
Any use or modification without prior notification and permission is illegal and will be prosecuted.
</font>
</p>"
$Fnote | out-file "$rPath\LongRunningJobReport.HTML" -Append -Width 1000000;

# Send the report email
 Write-host "Backup report executed for $i server(s)." -fore BLACK -background WHITE

#Remove-PSSnapin SqlServerCmdletSnapin100;

if (!$frm -or !$mailex -or !$recpt)
{
    Write-host "Reports cannot be emailed as either SMTP address or receipent address is not given..." -fore BLACK -background WHITE
    exit
}
sendEmail $frm $recpt "Mammoth :: Open RDP session Report - $Date" $mailex "$rPath\LongRunningJobReport.HTML"
EXIT