USE [msdb]
GO

/****** Object:  Job [DV_Missing_DIFF_Backup]    Script Date: 11/27/2018 6:32:16 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[HealthMEDX Process]]    Script Date: 11/27/2018 6:32:16 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[HealthMEDX Process]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[HealthMEDX Process]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DV_Missing_DIFF_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job sends list of databases for which DIFF backup is not done in last 12 Hours. This job can be rerun', 
		@category_name=N'[HealthMEDX Process]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DV_Missing_DIFF_Backup]    Script Date: 11/27/2018 6:32:16 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DV_Missing_DIFF_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF OBJECT_ID(''tempdb..#Temp'') IS NOT NULL
    DROP TABLE #Temp

SELECT x.database_name, z.physical_device_name, 
CONVERT(char(20), x.backup_finish_date, 108) FinishTime, x.backup_finish_date 
into #Temp
        from msdb.dbo.backupset x
JOIN ( SELECT a.database_name, max(a.backup_finish_date) backup_finish_date 
        FROM msdb.dbo.backupset a 
        WHERE type = ''I'' 
        GROUP BY a.database_name ) y on x.database_name = y.database_name 
        and x.backup_finish_date = y.backup_finish_date
        JOIN msdb.dbo.backupmediafamily z ON x.media_set_id = z.media_set_id 
order by x.backup_finish_date desc


Declare @Rowcount int

select @Rowcount  = count(*)
from #Temp T join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 30
and state = 0
and recovery_model = 1

if @Rowcount > 0
Begin

declare @tableHTML varchar(max)

	SET @tableHTML =
	N''<table border =1>'' +
	N''<tr><th>Database Name</th>
	<th>Backup Location</th>
	<th>Last Backup Finish Time</th>
	<th>Last Backup finish Date</th>	
	</tr>'' +
	CAST ( (
	SELECT td = database_name,'''',
	td = physical_device_name,'''',
	td = FinishTime,'''',
	td = backup_finish_date,''''	
	from #Temp T
       join sys.databases D on T.database_name = D.name
where DATEDIFF(hour, backup_finish_date, getdate()) > 30
       and state = 0
      and recovery_model = 1
	FOR XML PATH(''tr''), TYPE
	) AS NVARCHAR(MAX) ) +
	N''</table>''

--print @tableHTML

	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name =''HMDX_DBMail'',
		@from_address =  ''SNDB01-SNSERVER01@healthmedx.com'' ,	
		@recipients=''sql@datavail.com'',
		@copy_recipients= ''datacenter@healthmedx.com;sql@datavail.com'',
		@subject = ''DIFF Backups Missing in last 24 hour'',
		@body = @tableHTML,
		@body_format = ''HTML'' ;

End', 
		@database_name=N'master', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180328, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'e06dcb26-a392-4de1-90eb-81ee7fac8126'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

